# Zova market — o'z serverli Android ilova

Bu loyiha Claude'dagi Zova market ilovasini **o'zingizning serveringizga (Google Firebase)** ko'chiradi va uni **Android ilova** qiladi. Ilovadagi hamma imkoniyat saqlanadi:

- mijoz, kuryer, do'kon, admin va Ega bo'limlari;
- jarimalar, kuryer hisobi, bonuslar, «Kuryer chaqirish», jonli kuzatuv;
- reklama (rasm va video), ZOVA AI, Ma'lumotlar muharriri va boshqalar.

Claude'dagi 5 ta cheklov shu yo'l bilan hal bo'ladi:

| Muammo | Yechim |
|---|---|
| 1. Mijozga claude.ai akkaunti kerak edi | Mijoz **telefon raqami + SMS kod** bilan kiradi |
| 3. GPS bloklangan edi | Telefonning haqiqiy GPS'i ishlaydi. Kuryer joylashuvi ilova yopiq bo'lsa ham faol buyurtma davomida yuboriladi |
| 4. Onlayn to'lov yo'q edi | **Click va Payme**: buyurtma, kuryer hisobini to'ldirish (kamida 100 000 so'm) va jarima to'lovi |
| 5. Ilova yopiq bo'lsa xabar kelmasdi | **Push-bildirishnoma** quyidagilarga yuboriladi: mijozga buyurtma holati, do'kon/Ega/adminga yangi buyurtma, kuryerga biriktirilgan buyurtma, jarima, murojaatga javob, yangiliklar |
| 6. Telefon tasdiqlanmasdi | Har bir foydalanuvchi **SMS kod bilan tasdiqlanadi** (Firebase yoki Eskiz.uz). Mijozga «Yetkazildi» SMS boradi |

Qo'shimcha: mahsulot nomi yozilganda **internetdan haqiqiy rasm avtomatik qo'yiladi** (Brave Search). ZOVA AI **Gemini** asosida ishlaydi.

---

## Tuzilishi

```
zova-app/
├── web/                 ← ilovaning o'zi (Firebase Hosting'da turadi)
│   ├── index.html       ← Claude'dagi ilova (build-web.sh yasaydi)
│   ├── zova-server.js   ← ilovani Firebase'ga ulaydigan adapter
│   └── firebase-config.js ← SIZ to'ldirasiz
├── functions/           ← server: rollar, to'lovlar, push, AI, rasm qidiruvi
├── firestore.rules      ← kim nimani ko'ra/o'zgartira oladi (server tekshiradi)
├── firebase.json
├── build-web.sh         ← yangi tezkor.html → web/index.html
├── android/             ← Android ilova (Kotlin): SMS kirish, GPS, push, to'lov → Play Market
├── ios/                 ← iPhone ilova (Swift) → App Store
├── android-lite/        ← yengil APK (Claude'dagi ilovani ochadi), o'zingiz tarqatish uchun
└── store/               ← do'kon sahifasi matnlari va javoblar
```

Android ilova ichida web qism ochiladi. Shuning uchun ilovaga o'zgartirish kiritganda **Play Market'ga qayta yuklash shart emas**. `firebase deploy --only hosting` yetarli, hamma telefonlarda darhol yangilanadi.

---

## O'rnatish (bir marta, taxminan 1–2 soat)

### 0. Kompyutersiz ishga tushirish (faqat telefon va brauzer bilan, tavsiya etiladi)
Quyidagi 1–3-qadamlardagi buyruqlarni GitHub o'zi bajaradi.
1. **Firebase:** https://console.firebase.google.com → **Add project** → **Blaze** tarifi → **Firestore Database → Create** (europe-central2) → **Authentication → Phone** ni yoqing → **Project settings → Your apps → Web (</>)** qo'shing va `firebaseConfig = { … }` matnini nusxalang.
2. **Xizmat hisobi kaliti:** Firebase → Project settings → **Service accounts → Generate new private key** (JSON fayl yuklanadi). Keyin https://console.cloud.google.com/iam-admin/iam → shu hisob (`firebase-adminsdk-…`) yonidagi ✏️ → rol qo'shing: **Owner**.
3. **GitHub:** loyihani repo'ga yuklang (APK bo'limidagi kabi). **Settings → Secrets and variables → Actions**:
   - Secrets: `FIREBASE_SERVICE_ACCOUNT` (JSON faylning butun matni), `FIREBASE_WEB_CONFIG` (`firebaseConfig = { … }` matni). Ixtiyoriy: `GEMINI_API_KEY`, `CLICK_SECRET_KEY`, `PAYME_KEY`, `BRAVE_SEARCH_KEY`, `ESKIZ_EMAIL`, `ESKIZ_PASSWORD`.
   - Variables: `OWNER_PHONES` = `+998XXXXXXXXX,+998YYYYYYYYY` (ikkala Ega). Ixtiyoriy: `CLICK_SERVICE_ID`, `CLICK_MERCHANT_ID`, `PAYME_MERCHANT_ID`, `SMS_ON`, `SMS_LOGIN`, `YANDEX_GEOCODER_KEY`.
4. **Actions → Zova server (Firebase) → Run workflow.** 5–10 daqiqada tugaydi; natija sahifasida manzil chiqadi: `https://<project-id>.web.app`.
5. Shu manzilni telefonda oching yoki `zova-market.apk` → ⚙ Sozlamalar → server manziliga yozing. Endi **istalgan odam telefon raqami va SMS kod bilan ro'yxatdan o'tadi** — Claude akkaunti kerak emas.

Kalitsiz xizmatlar (to'lov, AI, rasm qidiruvi) avtomatik o'chiq turadi; kalitni qo'shib, workflow'ni qayta ishga tushirsangiz yoqiladi.

### Yoki kompyuterda (qo'lda)

Kerak bo'ladi: kompyuter, [Node.js 20](https://nodejs.org), [Android Studio](https://developer.android.com/studio) va Google akkaunti.

### 1. Firebase loyihasi
1. https://console.firebase.google.com → **Add project** → nom: `zova-market`.
2. **Upgrade → Blaze** tarifini yoqing. Cloud Functions va SMS uchun shart. Kichik hajmda deyarli tekin, lekin SMS pullik: narxini Firebase sahifasida ko'ring. Budget alert qo'yib qo'ying.
3. **Build → Firestore Database → Create**. Joylashuv: **europe-central2 (Warsaw)**, *production mode*.
4. **Build → Authentication → Sign-in method → Phone** ni yoqing.
5. **Project settings → General → Your apps → Web (</>)** ni qo'shing. Ko'rsatilgan `firebaseConfig` ni `web/firebase-config.js` ga ko'chiring.

### 2. Kalitlar
`functions/.env.example` dan nusxa oling va `functions/.env` deb saqlang. Ichini to'ldiring:
- `OWNER_PHONES=+998XXXXXXXXX,+998YYYYYYYYY` — **ikkala Eganing telefon raqamlari** (Kamronbek va Mirvohid), vergul bilan. Shu raqamlar bilan kirgan odam Ega huquqini oladi. Keyin Ega bo'limida har biri o'z kodini kiritadi: Kamronbek — @Kamron77, Mirvohid — vohid0609. Kim kirgani «O'zgarishlar tarixi»ga yoziladi.
- `APP_URL=https://<project-id>.web.app`
- `CLICK_SERVICE_ID`, `CLICK_MERCHANT_ID` (Click kabinetidan) va `PAYME_MERCHANT_ID` (Payme kabinetidan).

Maxfiy kalitlarni alohida kiriting. Ular faylga yozilmaydi:
```bash
npm install -g firebase-tools
firebase login
cp .firebaserc.example .firebaserc      # ichiga project-id ni yozing
firebase functions:secrets:set CLICK_SECRET_KEY
firebase functions:secrets:set PAYME_KEY
firebase functions:secrets:set GEMINI_API_KEY     # https://aistudio.google.com/apikey
firebase functions:secrets:set BRAVE_SEARCH_KEY   # https://brave.com/search/api (rasm qidiruvi)
```
Hali ulanmagan xizmatni `web/firebase-config.js` dagi `ZOVA_FEATURES` da `false` qilib qo'ying. Masalan, Click/Payme shartnomasi bo'lmasa `pay: false`.

### 3. Serverga chiqarish
```bash
cd functions && npm install && cd ..
firebase deploy
```

Android'dan kirish uchun bitta ruxsat bering:
1. Google Cloud Console → **IAM** oching.
2. `…-compute@developer.gserviceaccount.com` hisobiga **Service Account Token Creator** rolini qo'shing.
3. **IAM Service Account Credentials API** ni yoqing.

Tekshirish: `https://<project-id>.web.app` ni brauzerda oching, telefon raqam bilan kiring.

### 4. Android ilova
1. Firebase → **Project settings → Add app → Android**, paket nomi: `uz.zova.market`.
2. SHA-1 va SHA-256 barmoq izlarini qo'shing (SMS kirish uchun shart). Ularni `android` papkasida `./gradlew signingReport` buyrug'i ko'rsatadi. Play Market'ga chiqarganda **Play Console → App signing** dagi SHA'larni ham qo'shing.
3. `google-services.json` ni yuklab, `android/app/` ga qo'ying.
4. `android/gradle.properties` dagi `ZOVA_URL` ni o'z manzilingizga almashtiring.
5. Yoki (kompyuterda) Android Studio'da `android` papkasini oching. **Build → Generate Signed App Bundle / APK** ni bosing. APK telefonga o'rnatish uchun, AAB Play Market uchun.

### 4a. APK'ni kompyutersiz olish (GitHub, tavsiya etiladi)
Android Studio o'rnatmasdan, APK'ni GitHub o'zi yig'ib beradi (bepul):
1. https://github.com da akkaunt oching → **New repository** → nom: `zova-market` → **Private** → Create.
2. **Add file → Upload files**: shu loyihadagi hamma fayl va papkalarni (`.github` papkasi bilan birga) tashlang → **Commit**.
3. **Settings → Secrets and variables → Actions**:
   - **Secrets** bo'limida: `GOOGLE_SERVICES_JSON` — `google-services.json` faylining butun matni. Imzo kaliti uchun `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (qiymatlari sizga alohida berilgan `zova-imzo-kaliti.txt` faylida).
   - **Variables** bo'limida: `ZOVA_URL` = `https://<project-id>.web.app`.
4. Firebase'dagi Android ilovaga `zova-imzo-kaliti.txt` dagi **SHA1 va SHA256** ni qo'shing (SMS kirish uchun shart).
5. **Actions → Zova Android APK → Run workflow**. 5–8 daqiqadan keyin **Releases** bo'limida `zova-market.apk` (telefonga o'rnatish) va `zova-market.aab` (Play Market) paydo bo'ladi.

`android/` papkasiga har o'zgartirish yuklanganda yangi APK avtomatik yig'iladi.

### 5. Click va Payme
Click va Payme bilan **merchant shartnomasi** kerak (YaTT yoki yuridik shaxs).

Click kabinetida:
- Prepare URL: `https://<project-id>.web.app/pay/click/prepare`
- Complete URL: `https://<project-id>.web.app/pay/click/complete`

Payme kabinetida:
- Endpoint: `https://<project-id>.web.app/pay/payme`
- Hisob maydoni: `pay_id`
- Avval **test rejimida** sinab ko'ring: `.env` da `PAYME_TEST=true`.

Summani har doim server bazadan oladi. Mijoz narxni o'zgartirib yuborsa, server buyurtmani katalog bilan solishtiradi. Mos kelmasa, onlayn to'lovni rad etadi, xodimlarga «⚠️ Narx mos emas» deb ko'rsatadi va Ega/adminga push yuboradi.

### 5a. SMS xabarlar (Eskiz.uz)
**Ro'yxatdan o'tish kodi** hamma uchun (mijoz, kuryer, do'kon, admin) avtomatik keladi. Telefon raqam kiritilgach, 6 xonali kod SMS bilan boradi. Odatda buni Firebase yuboradi, hech narsa sozlash shart emas.

**«Yetkazildi» SMS** mijozga buyurtma holati «Yetkazildi» bo'lganda boradi, har buyurtmaga bir marta. Xodim ishga tasdiqlanganda ham unga SMS boradi. Buning uchun O'zbekiston SMS xizmati kerak:
1. https://eskiz.uz da ro'yxatdan o'ting va balansni to'ldiring.
2. Kabinetdagi **Shablonlar** bo'limida shu matnlarni tasdiqlatib oling (Eskiz tasdiqlanmagan matnni yubormaydi):
   - `Zova market: {id} raqamli buyurtmangiz yetkazildi. Xaridingiz uchun rahmat!`
   - `Zova market: tabriklaymiz, siz kuryer sifatida tasdiqlandingiz. Ilovaga kiring.` (va «do'kon» varianti)
   - `Zova market: kirish kodingiz {code}. Kodni hech kimga bermang.`
3. Kalitlarni kiriting va `functions/.env` da `SMS_ON=true` qiling:
```bash
firebase functions:secrets:set ESKIZ_EMAIL
firebase functions:secrets:set ESKIZ_PASSWORD
```
4. «Zova» nomi bilan yuborish uchun Eskiz'dan jo'natuvchi nomini oling va `SMS_FROM` ga yozing. Nom olinmaguncha `4546` raqamidan boradi.

**Kirish kodini ham Eskiz orqali yuborish** (ixtiyoriy). O'zbekistonda bu Firebase SMS'dan arzonroq va ishonchliroq. `web/firebase-config.js` da `smsLogin: "eskiz"` qiling, Android uchun `gradle.properties` da `ZOVA_SMS=eskiz` qiling (yoki GitHub Variables'ga `ZOVA_SMS=eskiz` qo'shing). Himoya:
- kod 5 daqiqa amal qiladi;
- 5 marta xato kiritilsa, kod bekor bo'ladi;
- bir raqamga daqiqasiga 1 ta, kuniga 5 ta kod yuboriladi;
- kunlik umumiy SMS chegarasi `SMS_DAILY_MAX`.

Ishchi arizasidagi telefon raqam avtomatik ravishda SMS bilan tasdiqlangan raqamga almashtiriladi. Shuning uchun boshqa birovning raqamini yozib bo'lmaydi.

### 6. Ilovani yangilash
Claude'da ilovaga o'zgartirish kiritilgach, yangi `tezkor.html` faylini oling va quyidagilarni bajaring:
```bash
./build-web.sh tezkor.html
firebase deploy --only hosting
```

---

## Play Market va App Store'ga chiqarish

Ikkala do'konga ham **o'z serverli versiya** chiqadi. Claude orqali ochiladigan yengil APK (`android-lite`) faqat telefonlarga o'zingiz tarqatish uchun: do'konlar uni rad etadi.

### Umumiy tayyorgarlik (bir marta)
1. Yuqoridagi 1–3-qadamlar: Firebase loyihasi, kalitlar, `firebase deploy`.
2. `web/privacy.html` dagi **aloqa telefoni va email**ni o'zingiznikiga almashtiring va qayta `firebase deploy --only hosting`.
3. Firebase → Authentication → Phone → **sinov raqami**: `+998 90 000 00 00`, kod `123456` (do'kon ko'rib chiquvchilari shu bilan kiradi).
4. Do'kon sahifasi matnlari, «Data safety» va «App Privacy» javoblari: `store/listing-uz.md`.

Ilovada **«Akkauntni o'chirish»** (Sozlamalar → Akkaunt) va maxfiylik siyosati havolasi bor — ikkala do'kon buni talab qiladi.

### Google Play
1. https://play.google.com/console — dasturchi akkaunti (bir martalik 25 $, shaxsni tasdiqlash).
2. **Create app** → nomi «Zova market», tili o'zbekcha, «App», «Free».
3. GitHub → Actions → **Zova Android APK** → Run. Tayyor `zova-market.aab` ni yuklab oling (Releases).
4. Play Console → **Testing → Closed testing** (shaxsiy akkauntda avval kamida 12 sinovchi 14 kun ishlatishi kerak) → AAB'ni yuklang.
5. **App signing**: Google o'z kalitini beradi. **App integrity → App signing** dagi SHA-1 va SHA-256 ni Firebase'dagi Android ilovaga qo'shing — aks holda Play'dan o'rnatilgan ilovada SMS kirish ishlamaydi.
6. «App content» bo'limlari: maxfiylik siyosati havolasi, akkauntni o'chirish havolasi (`/privacy.html#delete`), Data safety, joylashuv ruxsati deklaratsiyasi (kuryer GPS), sinov akkaunti.
7. Keyingi versiyalarni avtomatik yuklash (ixtiyoriy): Google Cloud'da service account yarating, Play Console → Users and permissions'da unga «Release» ruxsatini bering, JSON kalitini GitHub secret `PLAY_SERVICE_ACCOUNT_JSON` ga qo'ying. Shundan keyin har yig'ishda ilova «Internal testing»ga o'zi tushadi.

### App Store (iPhone)
Mac shart emas — ilova GitHub'ning Mac serverida yig'iladi va App Store Connect'ga o'zi yuklanadi.
1. https://developer.apple.com — **Apple Developer Program** (yiliga 99 $; shaxs yoki tashkilot, tasdiqlash bir necha kun).
2. App Store Connect → **Apps → +** → New App: nomi «Zova market», Bundle ID `uz.zova.market` (ro'yxatda bo'lmasa, Developer → Identifiers'da yarating, «Push Notifications»ni yoqing).
3. App Store Connect → **Users and Access → Integrations → App Store Connect API** → kalit yarating (**Admin**). Key ID, Issuer ID va `.p8` faylni saqlang.
4. Firebase → **Add app → iOS**, bundle `uz.zova.market` → `GoogleService-Info.plist` ni yuklab oling. Push uchun: Apple Developer → Keys → **APNs** kaliti yarating va Firebase → Project settings → Cloud Messaging → Apple app configuration'ga yuklang.
5. GitHub secret'lar: `APPLE_TEAM_ID`, `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_KEY_P8` (.p8 matni), `GOOGLE_SERVICE_INFO_PLIST` (plist matni). Variable: `ZOVA_URL`.
6. GitHub → Actions → **Zova iOS** → Run. 15–25 daqiqada ilova App Store Connect → **TestFlight**'ga tushadi. iPhone'da TestFlight ilovasi orqali sinab ko'ring.
7. App Store Connect'da sahifa matnlari, skrinshotlar (6.9" iPhone), App Privacy, sinov akkaunti → **Submit for Review**.

Apple ko'rib chiqishi odatda 1–3 kun. Rad etilsa, sababini yuboring — tuzatamiz.

---

## Rollar qanday ishlaydi
- **Mijoz**: SMS bilan kiradi va darhol buyurtma bera oladi.
- **Ega (2 ta)**: `OWNER_PHONES` dagi raqam bilan kiradi va o'z kodini kiritadi. Kamronbek @Kamron77, Mirvohid vohid0609 kodini kiritadi. Kodlar faqat PBKDF2 xesh ko'rinishida saqlanadi. Har bir o'zgarish «O'zgarishlar tarixi»da 7 kun turadi: kim, nima, eski va yangi qiymat, vaqt.
- **Admin**: ro'yxatdan o'tadi va Ega uni Xavfsizlik bo'limida tasdiqlaydi. Admin hech narsani o'zgartira olmaydi.
- **Kuryer**: ariza yuboradi, admin yoki Ega uni **✅ Tasdiqlash** tugmasi bilan qabul qiladi. Admin qabul kodini berib, kuryer o'zi kiritishi ham mumkin. Kod serverda tekshiriladi. Bitta kod uchun 10 ta xatodan keyin kod bekor bo'ladi va avtomatik yangisi yaratiladi.
- **Do'kon**: ro'yxatdan o'tadi va Ega «Xodimlar» bo'limida **✅ Tasdiqlash** tugmasini bosadi.

Rol (huquq) faqat serverda beriladi. Ilovani buzib ham o'zini xodim qilib bo'lmaydi.

## Ochiq aytib qo'yadigan cheklovlar
- Bu muhitda Android SDK yo'q, shuning uchun men **APK'ni yig'ib (compile qilib) sinab ko'ra olmadim**. Kod qo'lda tekshirildi. Web qismi (SMS kirish, ma'lumotlar, to'lov oynasi, Android ko'prigi) esa Firebase'ning soxta nusxasida sinovdan o'tdi. Android Studio'da birinchi yig'ishda kichik xato chiqsa, xabarini yuboring, tuzataman.
- **Adminning «faqat ko'rish»** cheklovi ilovada qo'yilgan. Server admin qurilmasiga ba'zi avtomatik yozuvlarga ruxsat beradi: buyurtma taqsimlash, qabul kodi, jarima avtomatikasi. Pul (kuryer hisobi), sozlamalar, xavfsizlik, reklama va yangiliklarni esa server faqat Egaga beradi.
- Kuryer buyurtmalar ro'yxatini o'zgartira oladi, chunki buyurtmani qabul qilish va avtomatik taqsimlash shuni talab qiladi. Bu Claude'dagi bilan bir xil. Kuryer o'z hisobiga pul yoza olmaydi.
- Claude'dagi ma'lumotlar (mahsulotlar, do'konlar, xodimlar) yangi serverga avtomatik o'tmaydi. Ularni ko'chirish uchun alohida eksport/import kerak bo'ladi.
- Video reklamalar bazada bo'laklab saqlanadi va har biri 8 MB gacha bo'lishi mumkin. Ko'p va katta videolar uchun keyinroq Firebase Storage'ga o'tkazish mumkin.
- **Xarita va marshrut:** o'z serveringizda quyidagi xizmatlar ulanadi.
  - Xarita: CARTO (Voyager / Dark Matter, OpenStreetMap asosida), «Tabiiy» ko'rinish OpenTopoMap'dan.
  - Yo'l bo'yicha marshrut va burilishlar: OSRM.
  - Ko'cha nomi va manzil qidiruvi: `geocode` funksiyasi. `functions/.env` da `YANDEX_GEOCODER_KEY` bo'lsa Yandex Geocoder ishlatiladi (O'zbekiston ko'chalari eng to'liq, lekin uni Yandex bo'lmagan xaritada ishlatish uchun Yandex'ning pullik litsenziyasi kerak). Kalit bo'lmasa OpenStreetMap Nominatim ishlatiladi (bepul, kichik hajm uchun).
  - Hammasi kichik hajmda bepul. Foydalanuvchi ko'paysa, o'z OSRM serveringiz yoki pullik xarita xizmati kerak bo'ladi.
- **Filiallar bo'yicha ajratish:** admin faqat o'z filialining buyurtmalari, mijozlari, kuryerlari va jarimalarini ko'radi. Bu cheklov hozircha ilova darajasida ishlaydi. Serverda (`firestore.rules`) xodimlar umumiy ma'lumotni o'qiy oladi. Filial bo'yicha qat'iy server cheklovi kerak bo'lsa, admin huquqiga (claims) `branch` qo'shib, qoidalarni kengaytirish mumkin.
