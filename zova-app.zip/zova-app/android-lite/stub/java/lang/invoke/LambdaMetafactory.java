package java.lang.invoke;
// Faqat kompilyatsiya uchun: d8 lambdalarni o'zi oddiy klasslarga aylantiradi
public final class LambdaMetafactory {
  public static CallSite metafactory(MethodHandles.Lookup l, String n, MethodType t, MethodType s, MethodHandle i, MethodType d) { return null; }
  public static CallSite altMetafactory(MethodHandles.Lookup l, String n, MethodType t, Object... a) { return null; }
}
