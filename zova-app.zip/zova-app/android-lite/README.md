# Zova market — yengil Android ilova (APK)

Tayyor APK: `zova-market.apk`. Android 7.0 va undan yangi telefonlarga o'rnatiladi.

- **Standart rejim:** ilova Claude'dagi Zova market'ni Chrome oynasida ochadi. Telefondagi Google yoki Claude akkaunti bilan bir marta kirasiz, keyin eslab qolinadi.
- **Server rejimi:** ⚙ Sozlamalar → o'z serveringiz manzili (masalan `https://zova-market.web.app`). Shundan keyin ilova to'liq ichki oynada ishlaydi: telefon raqami + SMS kod bilan kirish, GPS, rasm yuklash.

Sozlamalar: bosh ekrandagi «⚙ Sozlamalar» tugmasi yoki logotipni bosib turish.

Qayta yig'ish (Android Studio shart emas): `tools/` papkasiga aapt2, android.jar (API 34), d8.jar va uning kutubxonalari, apksig.jar qo'yiladi, keyin:
`./build.sh zova.jks <parol> zova`
