package uz.zova.market;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Zova market — Android ilova.
 *
 * Ikki rejim:
 *  1) Claude rejimi (standart): Zova market Claude'dagi manzilda ochiladi. Ochish Chrome
 *     oynasida (Custom Tab) bo'ladi, shuning uchun telefondagi Google / Claude akkauntidan
 *     bemalol kiriladi va bir marta kirgach eslab qolinadi.
 *  2) Server rejimi: o'z serveringiz (Firebase Hosting) manzili kiritilsa, ilova to'liq
 *     ichki oynada (WebView) ishlaydi: telefon raqami + SMS kod bilan kirish, GPS, rasm yuklash.
 */
public class MainActivity extends Activity {
    static final String CLAUDE_URL = "https://claude.ai/artifact/VAyqN5Yf79LRUT3V1hj6Bt";
    static final int BG = 0xFF060A16, SURFACE = 0xFF0D1426, ACCENT = 0xFF1F7BFF, INK = 0xFFEAF1FF, MUTED = 0xFF8E9CBC;
    static final int REQ_FILE = 11, REQ_LOC = 12;

    SharedPreferences prefs;
    WebView web;
    FrameLayout root;
    View errorView;
    ProgressBar bar;
    ValueCallback<Uri[]> fileCb;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;
    boolean openedOnce;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("zova", MODE_PRIVATE);
        openedOnce = state != null && state.getBoolean("opened");
        start();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("opened", openedOnce);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (web == null && server().isEmpty()) openClaude();   // ilova belgisi qayta bosilsa — darhol ochamiz
    }

    String server() { return prefs.getString("server", "").trim(); }
    String claudeUrl() { String u = prefs.getString("claude", "").trim(); return u.isEmpty() ? CLAUDE_URL : u; }

    void start() {
        if (web != null) { web.destroy(); web = null; }
        if (server().isEmpty()) showLauncher(); else showWeb(server());
    }

    /* ---------------- Claude rejimi ---------------- */
    void showLauncher() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(BG);
        int p = dp(28);
        box.setPadding(p, p, p, p);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        box.addView(logo, new LinearLayout.LayoutParams(dp(132), dp(132)));
        logo.setOnLongClickListener(v -> { settings(); return true; });

        TextView t = text("Zova market", 28, INK, true);
        t.setPadding(0, dp(18), 0, dp(6));
        box.addView(t);
        TextView s = text("Qamashi bo'ylab tez yetkazib berish", 15, MUTED, false);
        box.addView(s);

        Button open = button("Ilovani ochish", ACCENT, Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        lp.topMargin = dp(32);
        box.addView(open, lp);
        open.setOnClickListener(v -> openClaude());

        TextView hint = text("Birinchi marta ochilganda Claude akkauntingiz bilan kiring (Google yoki email). Keyin ilova sizni eslab qoladi.\n\nEga bo'limi faqat ilova egasining akkauntida ochiladi.", 13, MUTED, false);
        hint.setPadding(0, dp(18), 0, 0);
        box.addView(hint);

        Button set = button("⚙  Sozlamalar", SURFACE, MUTED);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        lp2.topMargin = dp(22);
        box.addView(set, lp2);
        set.setOnClickListener(v -> settings());

        setContentView(box);
        if (!openedOnce) { openedOnce = true; box.post(this::openClaude); }
    }

    void openClaude() {
        if (!online()) { toast("Internet yo'q. Ulanishni tekshirib, qayta bosing."); return; }
        Uri uri = Uri.parse(claudeUrl());
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        Bundle extras = new Bundle();
        extras.putBinder("android.support.customtabs.extra.SESSION", null);   // Custom Tab (ilova ichidagi Chrome oynasi)
        i.putExtras(extras);
        i.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR", BG);
        i.putExtra("androidx.browser.customtabs.extra.COLOR_SCHEME", 2);
        i.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 1);
        i.putExtra("android.support.customtabs.extra.ENABLE_URLBAR_HIDING", true);
        String[] browsers = {"com.android.chrome", "com.chrome.beta", "com.sec.android.app.sbrowser", "com.microsoft.emmx", null};
        for (String pkg : browsers) {
            try {
                Intent x = new Intent(i);
                if (pkg != null) x.setPackage(pkg);
                startActivity(x);
                return;
            } catch (ActivityNotFoundException ignored) { }
        }
        toast("Brauzer topilmadi. Google Chrome'ni o'rnating.");
    }

    /* ---------------- Server rejimi (WebView) ---------------- */
    void showWeb(String url) {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP));
        setContentView(root);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setGeolocationEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setUserAgentString(ws.getUserAgentString() + " ZovaAndroid/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        final String host = Uri.parse(url).getHost();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme() == null ? "" : u.getScheme();
                if ((sc.equals("https") || sc.equals("http")) && u.getHost() != null
                        && (u.getHost().equals(host) || u.getHost().endsWith(".firebaseapp.com") || u.getHost().endsWith("google.com") || u.getHost().endsWith("gstatic.com")))
                    return false;   // o'z sahifamiz va SMS tasdiqlash (reCAPTCHA) ichkarida ochiladi
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { toast("Ochib bo'lmadi"); }
                return true;        // xarita, tel:, to'lov va boshqa havolalar — tashqi ilovada
            }
            @Override
            public void onPageFinished(WebView v, String u) { bar.setVisibility(View.GONE); hideError(); }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) { bar.setVisibility(p < 100 ? View.VISIBLE : View.GONE); bar.setProgress(p); }
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (hasLoc()) { cb.invoke(origin, true, true); return; }
                geoOrigin = origin; geoCb = cb;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(params.createIntent(), REQ_FILE); }
                catch (Exception e) { fileCb = null; toast("Fayl tanlab bo'lmadi"); return false; }
                return true;
            }
        });
        web.loadUrl(url);
    }

    boolean hasLoc() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_LOC && geoCb != null) { geoCb.invoke(geoOrigin, hasLoc(), true); geoCb = null; }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        if (code == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCb = null;
        } else super.onActivityResult(code, result, data);
    }

    void showError() {
        if (errorView != null) return;
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(BG);
        b.setPadding(dp(28), dp(28), dp(28), dp(28));
        b.addView(text("📶", 48, INK, false));
        b.addView(text("Internet bilan aloqa yo'q", 20, INK, true));
        TextView m = text("Ulanishni tekshiring va qayta urinib ko'ring.", 14, MUTED, false);
        m.setPadding(0, dp(6), 0, dp(20));
        b.addView(m);
        Button r = button("Qayta urinish", ACCENT, Color.WHITE);
        b.addView(r, new LinearLayout.LayoutParams(-1, dp(52)));
        r.setOnClickListener(v -> { hideError(); web.reload(); });
        errorView = b;
        root.addView(b, new FrameLayout.LayoutParams(-1, -1));
    }

    void hideError() { if (errorView != null) { root.removeView(errorView); errorView = null; } }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(function(){try{return !!(window.ZovaBack&&window.ZovaBack())}catch(e){return false}})()", v -> {
            if ("true".equals(v)) return;   // ilova o'zi oynani yopdi
            if (web.canGoBack()) web.goBack(); else finish();
        });
    }

    @Override
    protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); if (web != null) web.onPause(); }

    @Override
    protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    /* ---------------- Sozlamalar ---------------- */
    void settings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView l1 = text("O'z serveringiz manzili (Firebase). Bo'sh qoldirsangiz, Claude'dagi Zova market ochiladi.", 13, MUTED, false);
        box.addView(l1);
        final EditText srv = input(server(), "https://loyiha-id.web.app");
        box.addView(srv);
        TextView l2 = text("Claude'dagi ilova havolasi", 13, MUTED, false);
        l2.setPadding(0, dp(14), 0, 0);
        box.addView(l2);
        final EditText cl = input(claudeUrl(), CLAUDE_URL);
        box.addView(cl);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Sozlamalar")
            .setView(box)
            .setPositiveButton("Saqlash", (d, w) -> {
                String s = srv.getText().toString().trim(), c = cl.getText().toString().trim();
                if (!s.isEmpty() && !s.startsWith("https://")) { toast("Server manzili https:// bilan boshlanishi kerak"); return; }
                if (!c.isEmpty() && !c.startsWith("https://")) { toast("Havola https:// bilan boshlanishi kerak"); return; }
                prefs.edit().putString("server", s).putString("claude", c.equals(CLAUDE_URL) ? "" : c).apply();
                openedOnce = false;
                start();
            })
            .setNegativeButton("Bekor", null)
            .setNeutralButton("Standart", (d, w) -> { prefs.edit().clear().apply(); openedOnce = false; start(); })
            .show();
    }

    /* ---------------- yordamchilar ---------------- */
    boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            return n != null && n.isConnected();
        } catch (Exception e) { return true; }
    }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setStateListAnimator(null);
        return b;
    }

    EditText input(String value, String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(14);
        return e;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
