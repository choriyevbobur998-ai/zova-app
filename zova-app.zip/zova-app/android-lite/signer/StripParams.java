import org.objectweb.asm.*;
import java.nio.file.*;
/* JDK 21 javac yozadigan MethodParameters atributini olib tashlaydi (eski d8 uni o'qiy olmaydi) */
public class StripParams {
  public static void main(String[] a) throws Exception {
    for (String f : a) {
      Path p = Paths.get(f); ClassReader cr = new ClassReader(Files.readAllBytes(p)); ClassWriter cw = new ClassWriter(0);
      cr.accept(new ClassVisitor(Opcodes.ASM7, cw) {
        @Override public MethodVisitor visitMethod(int ac, String n, String d, String s, String[] e) {
          return new MethodVisitor(Opcodes.ASM7, super.visitMethod(ac, n, d, s, e)) { @Override public void visitParameter(String name, int access) {} };
        }
      }, 0);
      Files.write(p, cw.toByteArray());
    }
  }
}
