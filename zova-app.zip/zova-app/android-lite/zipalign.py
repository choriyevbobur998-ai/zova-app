# APK ichidagi siqilmagan (STORED) fayllarni 4 baytga tekislaydi (Android 11+ talab qiladi)
import sys, zipfile
src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src)
with open(dst, "wb") as f:
    zout = zipfile.ZipFile(f, "w")
    for info in zin.infolist():
        data = zin.read(info.filename)
        ni = zipfile.ZipInfo(info.filename, date_time=info.date_time)
        ni.compress_type = zipfile.ZIP_STORED if (info.filename == "resources.arsc" or info.filename.endswith(".png")) else zipfile.ZIP_DEFLATED
        ni.external_attr = info.external_attr
        if ni.compress_type == zipfile.ZIP_STORED:
            hdr = 30 + len(ni.filename.encode())
            pad = (4 - (f.tell() + hdr) % 4) % 4
            ni.extra = b"\0" * pad
        zout.writestr(ni, data)
    zout.close()
print("aligned", dst)
