#!/bin/sh
# Zova market APK'ni Android Studio'siz yig'adi. Ishlatish: ./build.sh <keystore> <parol> [alias]
set -e
cd "$(dirname "$0")"
KS="$1"; PW="$2"; AL="${3:-zova}"
D8CP="$(ls tools/*.jar | grep -v -E 'android.jar|apksig.jar' | paste -sd:)"
rm -rf build && mkdir -p build/flat build/gen build/classes build/dex out
tools/aapt2 compile --dir res -o build/flat/res.zip
tools/aapt2 link -I tools/android.jar --manifest AndroidManifest.xml --java build/gen -o build/base.apk build/flat/res.zip --min-sdk-version 24 --target-sdk-version 34 --version-code 1 --version-name 1.0
mkdir -p build/stub && javac -nowarn -source 8 -target 8 -bootclasspath tools/android.jar -d build/stub stub/java/lang/invoke/LambdaMetafactory.java 2>&1 | grep -v -E "warning|JAVA_TOOL" || true
javac -nowarn -source 8 -target 8 -bootclasspath tools/android.jar:build/stub -d build/classes $(find src build/gen -name '*.java') 2>&1 | grep -v -E "warning|JAVA_TOOL" || true
javac -nowarn -cp tools/asm-7.1.jar -d build/strip signer/StripParams.java 2>&1 | grep -v JAVA_TOOL || true
java -cp "tools/asm-7.1.jar:build/strip" StripParams $(find build/classes -name '*.class') 2>&1 | grep -v JAVA_TOOL || true
java -cp "$D8CP" com.android.tools.r8.D8 --release --min-api 24 --output build/dex $(find build/classes -name '*.class') 2>&1 | grep -v JAVA_TOOL || true
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)
python3 zipalign.py build/unsigned.apk build/aligned.apk
javac -nowarn -cp tools/apksig.jar -d build/signer signer/Sign.java 2>&1 | grep -v JAVA_TOOL || true
java -cp "tools/apksig.jar:build/signer" Sign "$KS" "$PW" "$AL" build/aligned.apk out/zova-market.apk 2>&1 | grep -v JAVA_TOOL
ls -la out/zova-market.apk
