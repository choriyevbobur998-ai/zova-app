# Do'kon sahifasi matnlari (Play Market va App Store)

**Nomi:** Zova market
**Qisqa tavsif (80 belgi):** Qamashi bo'ylab oziq-ovqat va mahsulotlarni tez yetkazib berish
**Kategoriya:** Oziq-ovqat va ichimliklar (App Store: Food & Drink) · Yosh chegarasi: 4+ / Hamma uchun

**To'liq tavsif:**
Zova market — Qamashi tumanidagi do'kon va restoranlardan buyurtmani uyingizgacha yetkazib beradigan xizmat.

• Telefon raqamingiz bilan bir daqiqada ro'yxatdan o'ting — SMS kod keladi
• Do'kon, restoran va mahsulotlarni qidiring, savatga qo'shing
• Manzilni xaritada belgilang yoki joylashuvingizni avtomatik aniqlang
• Naqd, Click yoki Payme orqali to'lang
• Buyurtma holatini va kuryerni xaritada jonli kuzating
• Har buyurtmadan bonus to'plang
• «Kuryer chaqirish» — istalgan narsani bir manzildan boshqasiga yuboring
• Buyurtma yetkazilganda SMS va bildirishnoma keladi

Kuryerlar va do'konlar uchun alohida bo'limlar: buyurtmalarni qabul qilish, hisob, jarimalar va kuzatuv.

**Kalit so'zlar (App Store, 100 belgi):** yetkazib berish,dostavka,qamashi,oziq-ovqat,restoran,kuryer,market,buyurtma,zova

**Maxfiylik siyosati:** https://<project-id>.web.app/privacy.html
**Akkauntni o'chirish havolasi (Play):** https://<project-id>.web.app/privacy.html#delete
**Qo'llab-quvvatlash sahifasi (App Store):** https://<project-id>.web.app/privacy.html

## Ko'rib chiquvchilar uchun sinov akkaunti (ikkala do'kon so'raydi)
Firebase → Authentication → Sign-in method → Phone → **Phone numbers for testing**: `+998 90 000 00 00`, kod `123456`.
Do'kon formasidagi «App access / Sign-in information» bo'limiga shu raqam va kodni yozing.
(Kirish kodi Eskiz orqali yuborilsa — `smsLogin: "eskiz"` — sinov raqami ishlamaydi, ko'rib chiqish paytida `firebase` rejimida qoldiring.)

## Play Console: Data safety (ma'lumotlar xavfsizligi) javoblari
- To'planadi: telefon raqam, ism, manzil, aniq joylashuv, xaridlar tarixi, ilova ichidagi xabarlar (murojaatlar), qurilma ID (push token)
- Maqsad: ilova ishlashi; reklama yoki boshqa kompaniyaga berish — yo'q
- Shifrlangan holda uzatiladi — ha · Foydalanuvchi o'chirishni so'rashi mumkin — ha
- Joylashuv fonda: faqat kuryerlar, faol buyurtma paytida, doimiy bildirishnoma bilan (Play «Location permissions» deklaratsiyasida shu matn va 30 soniyalik video so'raladi)

## App Store: App Privacy javoblari
Contact Info (Name, Phone Number), Location (Precise), Purchases, User Content (Customer Support), Identifiers (Device ID) — barchasi «App Functionality», «Linked to user», «Not used for tracking».
