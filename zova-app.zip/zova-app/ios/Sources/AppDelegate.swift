import UIKit
import UserNotifications
import FirebaseCore
import FirebaseMessaging

/// Ilova kirish nuqtasi: Firebase (push-bildirishnomalar) va asosiy oyna.
@main
final class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate, MessagingDelegate {
    var window: UIWindow?
    static private(set) var pushToken: String?
    static var onToken: ((String?) -> Void)?

    func application(_ app: UIApplication, didFinishLaunchingWithOptions opts: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist") != nil {
            FirebaseApp.configure()
            Messaging.messaging().delegate = self
        }
        UNUserNotificationCenter.current().delegate = self
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = WebViewController()
        window?.makeKeyAndVisible()
        return true
    }

    /// Bildirishnomaga ruxsat so'rash (ilova ochilgach, web qismi push tokenini so'raganda)
    static func requestPush(_ done: @escaping (String?) -> Void) {
        guard FirebaseApp.app() != nil else { return done(nil) }
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return done(nil) }
                UIApplication.shared.registerForRemoteNotifications()
                if let t = pushToken { return done(t) }
                // Birinchi ishga tushishda token APNs'dan keyinroq keladi — kelganda web qismiga beramiz
                onToken = { t in onToken = nil; done(t) }
                Messaging.messaging().token { t, _ in if let t = t { onToken = nil; done(t) } }
            }
        }
    }

    func application(_ app: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken token: Data) {
        Messaging.messaging().apnsToken = token
    }

    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        AppDelegate.pushToken = fcmToken
        AppDelegate.onToken?(fcmToken)
    }

    // Ilova ochiq bo'lganda ham bildirishnoma ko'rinsin
    func userNotificationCenter(_ c: UNUserNotificationCenter, willPresent n: UNNotification, withCompletionHandler done: @escaping (UNNotificationPresentationOptions) -> Void) {
        done([.banner, .sound, .list])
    }

    func userNotificationCenter(_ c: UNUserNotificationCenter, didReceive r: UNNotificationResponse, withCompletionHandler done: @escaping () -> Void) {
        done()   // ilova oldinga chiqadi, holat Firestore orqali darhol yangilanadi
    }
}
