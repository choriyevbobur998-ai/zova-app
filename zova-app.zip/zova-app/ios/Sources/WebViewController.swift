import UIKit
import WebKit
import UserNotifications

/// Asosiy oyna: Zova market web-ilovasi (Firebase Hosting) WKWebView ichida ochiladi.
/// Web qismi `window.ZovaNative` orqali telefon imkoniyatlaridan foydalanadi (push, bildirishnoma, tashqi havolalar).
final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    private var web: WKWebView!
    private let errorView = UIView()
    private let brand = UIColor(red: 6/255, green: 10/255, blue: 22/255, alpha: 1)
    private lazy var appURL: URL = {
        let s = (Bundle.main.object(forInfoDictionaryKey: "ZovaURL") as? String) ?? ""
        return URL(string: s) ?? URL(string: "https://example.com")!
    }()

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = brand

        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []   // reklama videolari ovozsiz o'ynaydi
        cfg.websiteDataStore = .default()
        let ucc = WKUserContentController()
        ucc.add(WeakHandler(self), name: "zova")
        // web/zova-server.js kutayotgan ko'prik: har bir chaqiruv javobi window.__zovaCb(id, qiymat) orqali qaytadi
        let bridge = """
        (function(){
          var post = function(m, a){ try { window.webkit.messageHandlers.zova.postMessage({ m: m, a: a }); } catch (e) {} };
          window.ZovaNative = {
            getAuthToken: function(id){ setTimeout(function(){ window.__zovaCb && window.__zovaCb(id, null); }, 0); },
            getPushToken: function(id){ post('push', [id]); },
            uid: function(){ return ''; },
            openUrl: function(u){ post('open', [u]); },
            notify: function(t, b){ post('notify', [t, b]); },
            logout: function(){}
          };
        })();
        """
        ucc.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = ucc
        cfg.applicationNameForUserAgent = "ZovaiOS/1.0"

        web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.isOpaque = false
        web.backgroundColor = brand
        web.scrollView.backgroundColor = brand
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = true
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        let refresh = UIRefreshControl()
        refresh.tintColor = .white
        refresh.addTarget(self, action: #selector(reload(_:)), for: .valueChanged)
        web.scrollView.refreshControl = refresh

        buildErrorView()
        web.load(URLRequest(url: appURL))
    }

    @objc private func reload(_ sender: UIRefreshControl) { web.reload(); sender.endRefreshing() }

    // MARK: ko'prik
    func userContentController(_ c: WKUserContentController, didReceive msg: WKScriptMessage) {
        guard msg.frameInfo.isMainFrame, msg.frameInfo.request.url?.host == appURL.host,
              let d = msg.body as? [String: Any], let m = d["m"] as? String else { return }
        let a = d["a"] as? [Any] ?? []
        switch m {
        case "push":
            guard let id = a.first as? String else { return }
            AppDelegate.requestPush { [weak self] t in self?.reply(id, t) }
        case "open":
            if let s = a.first as? String, let u = URL(string: s), ["https", "tel"].contains(u.scheme ?? "") { UIApplication.shared.open(u) }
        case "notify":
            guard UIApplication.shared.applicationState != .active else { return }
            let n = UNMutableNotificationContent()
            n.title = a.first as? String ?? "Zova market"
            n.body = a.count > 1 ? (a[1] as? String ?? "") : ""
            n.sound = .default
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: UUID().uuidString, content: n, trigger: nil))
        default: break
        }
    }

    private func reply(_ id: String, _ value: String?) {
        let enc: (String) -> String = { s in
            let data = try? JSONSerialization.data(withJSONObject: [s])
            let arr = data.flatMap { String(data: $0, encoding: .utf8) } ?? "[\"\"]"
            return String(arr.dropFirst().dropLast())
        }
        let js = "window.__zovaCb && window.__zovaCb(\(enc(id)), \(value.map(enc) ?? "null"))"
        DispatchQueue.main.async { self.web.evaluateJavaScript(js, completionHandler: nil) }
    }

    // MARK: havolalar
    func webView(_ w: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let u = action.request.url else { return decisionHandler(.cancel) }
        let host = u.host ?? ""
        let inside = u.scheme == "https" && (host == appURL.host || host.hasSuffix(".firebaseapp.com") || host.hasSuffix("google.com") || host.hasSuffix("gstatic.com"))
        if action.targetFrame?.isMainFrame == false || inside || u.scheme == "about" || u.scheme == "blob" || u.scheme == "data" {
            if action.targetFrame == nil { UIApplication.shared.open(u); return decisionHandler(.cancel) }   // target=_blank
            return decisionHandler(.allow)
        }
        UIApplication.shared.open(u)   // tel:, xarita, Click/Payme va boshqa saytlar — tashqi ilovada
        decisionHandler(.cancel)
    }

    func webView(_ w: WKWebView, createWebViewWith c: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = action.request.url { UIApplication.shared.open(u) }
        return nil
    }

    // JavaScript alert/confirm (ilova kam ishlatadi, lekin bo'lsa ishlasin)
    func webView(_ w: WKWebView, runJavaScriptAlertPanelWithMessage m: String, initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: m, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in done() })
        present(a, animated: true)
    }

    func webView(_ w: WKWebView, runJavaScriptConfirmPanelWithMessage m: String, initiatedByFrame f: WKFrameInfo, completionHandler done: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: m, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Bekor", style: .cancel) { _ in done(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in done(true) })
        present(a, animated: true)
    }

    // MARK: internet yo'q
    func webView(_ w: WKWebView, didFailProvisionalNavigation n: WKNavigation!, withError e: Error) { showError() }
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) { errorView.isHidden = true }
    func webViewWebContentProcessDidTerminate(_ w: WKWebView) { w.reload() }   // xotira tugasa — qotib qolmasdan qayta yuklanadi

    private func buildErrorView() {
        errorView.backgroundColor = brand
        errorView.isHidden = true
        errorView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorView)
        NSLayoutConstraint.activate([
            errorView.topAnchor.constraint(equalTo: view.topAnchor), errorView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            errorView.leadingAnchor.constraint(equalTo: view.leadingAnchor), errorView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        let title = UILabel(); title.text = "Internet bilan aloqa yo'q"; title.textColor = .white; title.font = .boldSystemFont(ofSize: 20)
        let sub = UILabel(); sub.text = "Ulanishni tekshirib, qayta urinib ko'ring."; sub.textColor = UIColor(white: 0.65, alpha: 1); sub.numberOfLines = 0; sub.textAlignment = .center
        let btn = UIButton(type: .system); btn.setTitle("Qayta urinish", for: .normal); btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = UIColor(red: 31/255, green: 123/255, blue: 1, alpha: 1); btn.layer.cornerRadius = 14
        btn.titleLabel?.font = .boldSystemFont(ofSize: 17)
        btn.contentEdgeInsets = UIEdgeInsets(top: 14, left: 28, bottom: 14, right: 28)
        btn.addTarget(self, action: #selector(retry), for: .touchUpInside)
        let st = UIStackView(arrangedSubviews: [title, sub, btn]); st.axis = .vertical; st.spacing = 14; st.alignment = .center
        st.translatesAutoresizingMaskIntoConstraints = false
        errorView.addSubview(st)
        NSLayoutConstraint.activate([st.centerYAnchor.constraint(equalTo: errorView.centerYAnchor), st.leadingAnchor.constraint(equalTo: errorView.leadingAnchor, constant: 28), st.trailingAnchor.constraint(equalTo: errorView.trailingAnchor, constant: -28)])
    }

    private func showError() { errorView.isHidden = false }
    @objc private func retry() { errorView.isHidden = true; web.load(URLRequest(url: appURL)) }
}

/// WKUserContentController o'ziga kuchli havola saqlaydi — xotira oqmasligi uchun oraliq obyekt
private final class WeakHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ t: WKScriptMessageHandler) { target = t }
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) { target?.userContentController(c, didReceive: m) }
}
