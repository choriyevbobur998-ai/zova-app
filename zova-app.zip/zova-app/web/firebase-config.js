/* Firebase Console → Project settings → Your apps → Web app → SDK config dan nusxa oling */
window.ZOVA_FIREBASE_CONFIG = {
  apiKey: "AIza...",
  authDomain: "SIZNING-PROJECT-ID.firebaseapp.com",
  projectId: "SIZNING-PROJECT-ID",
  storageBucket: "SIZNING-PROJECT-ID.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:0000000000000000"
};
window.ZOVA_REGION = "europe-central2";
/* Kalit hali qo'yilmagan xizmatni o'chirib qo'ying (false) */
window.ZOVA_FEATURES = { pay: true, img: true, ai: true,
  /* Xaritada ko'cha nomi va manzil qidiruvi (server: Yandex Geocoder yoki OpenStreetMap) */
  geo: true,
  /* Kirish kodi qaysi xizmat orqali boradi: "firebase" (Google SMS) yoki "eskiz" (Eskiz.uz, O'zbekistonda arzonroq) */
  smsLogin: "firebase" };
