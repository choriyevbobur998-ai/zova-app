/* =====================================================================
   ZOVA market — o'z serveri (Firebase) adapteri
   ---------------------------------------------------------------------
   Ilova (index.html) claude.ai platformasi uchun yozilgan va
   window.claude.use("db" | "user" | "sample") orqali ishlaydi.
   Bu fayl xuddi shu interfeysni Firebase ustida beradi:
     db     → Cloud Firestore (oflayn kesh bilan)
     user   → Firebase Auth (telefon raqam + SMS kod)
     sample → Cloud Function "ai" (Gemini) — ZOVA AI
   Qo'shimcha: onlayn to'lov (Click/Payme), push, Android bilan ko'prik.
   Bu skript index.html dagi ILOVA SKRIPTIDAN OLDIN ulanadi.
   ===================================================================== */
(function () {
  "use strict";
  const CONF = window.ZOVA_FIREBASE_CONFIG;
  const FEAT = Object.assign({ pay: true, img: true, ai: true, geo: true }, window.ZOVA_FEATURES || {});
  const REGION = window.ZOVA_REGION || "europe-central2";
  const SDK = "https://www.gstatic.com/firebasejs/10.12.2/";
  window.ZOVA_SERVER = true;

  let readyRes; const ready = new Promise(r => { readyRes = r; });
  window.claude = { use: async name => { const z = await ready; return z[name] || null; } };

  /* ---------- Android ko'prigi (ilova Android ichida ochilganda) ---------- */
  const NATIVE = window.ZovaNative || null;
  let cbSeq = 0; const cbs = {};
  window.__zovaCb = (id, val) => { const f = cbs[id]; if (f) { delete cbs[id]; f(val); } };
  const nativeCall = (method, ...args) => new Promise(res => {
    if (!NATIVE || typeof NATIVE[method] !== "function") return res(null);
    const id = "c" + (++cbSeq); cbs[id] = res;
    try { NATIVE[method](id, ...args); } catch (e) { delete cbs[id]; res(null); }
    setTimeout(() => { if (cbs[id]) { delete cbs[id]; res(null); } }, 30000);
  });

  /* ---------- Kichik UI: kirish oynasi va to'lov oynasi ---------- */
  const css = `
  #zv-ov{position:fixed;inset:0;z-index:99999;background:#070b16;color:#eef2ff;display:flex;align-items:center;justify-content:center;font:16px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:16px}
  #zv-ov .bx{width:100%;max-width:380px;display:flex;flex-direction:column;gap:12px;text-align:center}
  #zv-ov h1{font-size:22px;margin:4px 0}
  #zv-ov input{font:inherit;font-size:20px;padding:14px;border-radius:14px;border:1px solid #2a3552;background:#0f1628;color:#fff;text-align:center;letter-spacing:.06em}
  #zv-ov button{font:inherit;font-weight:700;padding:14px;border-radius:14px;border:0;background:#2f7bff;color:#fff}
  #zv-ov button.gh{background:transparent;border:1px solid #2a3552}
  #zv-ov button:disabled{opacity:.5}
  #zv-ov .er{color:#ff8080;font-size:14px;min-height:18px}
  #zv-ov .mu{color:#9aa6c4;font-size:14px}
  #zv-pay{position:fixed;inset:0;z-index:99998;background:rgba(0,0,0,.6);display:flex;align-items:flex-end;justify-content:center}
  #zv-pay .sh{background:#0f1628;color:#eef2ff;width:100%;max-width:480px;border-radius:22px 22px 0 0;padding:20px 16px 28px;display:flex;flex-direction:column;gap:10px;font:16px system-ui,sans-serif}
  #zv-pay button{font:inherit;font-weight:700;padding:15px;border-radius:14px;border:0;color:#fff}
  #zv-pay .ck{background:#0aa0e8}#zv-pay .pm{background:#33cccc;color:#05303a}#zv-pay .cl{background:transparent;border:1px solid #2a3552}`;
  const st = document.createElement("style"); st.textContent = css;
  (document.head || document.documentElement).appendChild(st);
  const el = (h) => { const d = document.createElement("div"); d.innerHTML = h.trim(); return d.firstChild; };
  const toast = t => { try { if (typeof window.toast === "function") return window.toast(t); } catch (e) {} };

  /* ---------- Firebase'ni yuklash ---------- */
  let app, auth, fs, fns, A, F, Fn, me = null, lvl = "";
  const ERR = { "permission-denied": "permission_denied", "not-found": "invalid_argument", "invalid-argument": "invalid_argument", "failed-precondition": "invalid_argument", "unavailable": "unavailable", "deadline-exceeded": "unavailable", "resource-exhausted": "rate_limited", "unauthenticated": "permission_denied" };
  const wrapErr = e => { const c = (e && e.code || "").replace(/^(firestore|functions|auth)\//, ""); const o = new Error((e && e.message) || String(e)); o.code = ERR[c] || c || "unknown"; return o; };
  const guardP = p => p.catch(e => { throw wrapErr(e); });

  async function call(name, data) {
    const f = Fn.httpsCallable(fns, name, { timeout: 60000 });
    try { return (await f(data || {})).data; } catch (e) { throw wrapErr(e); }
  }

  /* ---------- db adapteri (window.claude "db" bilan bir xil) ---------- */
  const isPlain = v => v && typeof v === "object" && !Array.isArray(v) && (Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null);
  function flat(o, pre, out) { for (const k of Object.keys(o)) { const v = o[k]; if (v === undefined) continue; if (isPlain(v) && Object.keys(v).length) flat(v, pre.concat(k), out); else out.push([pre.concat(k), v]); } return out; }
  const clean = v => JSON.parse(JSON.stringify(v === undefined ? null : v));
  const snapDoc = d => ({ id: d.id, exists: d.exists(), data: () => d.data() });
  const snapCol = s => ({ docs: s.docs.map(snapDoc), empty: s.empty, size: s.size });

  function docRef(path) {
    const ref = F.doc(fs, path);
    return {
      id: ref.id, path,
      get: () => guardP(F.getDoc(ref).then(snapDoc)),
      set: data => guardP(F.setDoc(ref, clean(data))),
      update: data => {
        const pairs = flat(clean(data), [], []);
        if (!pairs.length) return Promise.resolve();
        const args = []; for (const [p, v] of pairs) args.push(new F.FieldPath(...p), v);
        return guardP(F.updateDoc(ref, ...args));
      },
      delete: () => guardP(F.deleteDoc(ref)),
      onSnapshot: (cb, err) => F.onSnapshot(ref, s => cb(snapDoc(s)), e => err && err(wrapErr(e))),
      acquire: ({ holder, ttlMs, data } = {}) => guardP(F.runTransaction(fs, async tx => {
        const s = await tx.get(ref), d = s.exists() ? s.data() : {}, L = d._lease, now = Date.now();
        if (L && L.until > now && L.holder !== holder) return { acquired: false, holder: L.holder };
        tx.set(ref, Object.assign({}, d, data ? clean(data) : {}, { _lease: { holder: holder || "", until: now + (ttlMs || 30000) } }));
        return { acquired: true };
      })),
    };
  }
  function colRef(name) {
    const ref = F.collection(fs, name);
    return {
      id: name, path: name,
      doc: id => docRef(name + "/" + (id || F.doc(ref).id)),
      get: () => guardP(F.getDocs(ref).then(snapCol)),
      add: data => guardP(F.addDoc(ref, clean(data)).then(r => docRef(name + "/" + r.id))),
      onSnapshot: (cb, err) => F.onSnapshot(ref, s => cb(snapCol(s)), e => err && err(wrapErr(e))),
      where() { return this; },
    };
  }
  const dbApi = { doc: docRef, collection: colRef };

  /* ---------- user adapteri ---------- */
  const userApi = {
    isOwner: async () => lvl === "owner",
    canEdit: async () => !!lvl,   // owner | admin | courier | store
    id: async () => me && me.uid,
    me: async () => ({ name: (me && me.displayName) || "", phone: (me && me.phoneNumber) || "" }),
    profiles: async () => ({}),
  };

  /* ---------- sample adapteri (ZOVA AI → Gemini, server orqali) ---------- */
  async function sample(prompt, opts = {}) {
    if (!FEAT.ai) { const e = new Error("off"); e.code = "sampling_disabled"; throw e; }
    if (opts.signal && opts.signal.aborted) { const e = new Error("cancelled"); e.code = "cancelled"; throw e; }
    const r = await call("ai", { prompt: String(prompt).slice(0, 30000), json: false });
    if (opts.signal && opts.signal.aborted) { const e = new Error("cancelled"); e.code = "cancelled"; e.text = r.text; throw e; }
    if (opts.onText) try { opts.onText({ text: r.text || "" }); } catch (e) {}
    return { text: r.text || "" };
  }
  sample.json = async (prompt, opts = {}) => {
    const r = await call("ai", { prompt: String(prompt).slice(0, 30000), json: true });
    if (opts.signal && opts.signal.aborted) { const e = new Error("cancelled"); e.code = "cancelled"; throw e; }
    return r.data;
  };

  /* ---------- To'lov (Click / Payme) ---------- */
  function openUrl(u) {
    if (NATIVE && NATIVE.openUrl) { try { NATIVE.openUrl(u); return; } catch (e) {} }
    const w = window.open(u, "_blank"); if (w) w.opener = null; else location.href = u;
  }
  async function pay(args) {
    if (!FEAT.pay) return toast("Onlayn to'lov yoqilmagan");
    let r; try { r = await call("createPayment", args); } catch (e) { return toast("To'lov yaratilmadi: " + (e.message || "")); }
    if (!r || !r.payId) return toast((r && r.err) || "To'lov yaratilmadi");
    const sum = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " so'm";
    const box = el(`<div id="zv-pay"><div class="sh"><b style="font-size:18px">💳 To'lov: ${sum(r.amount)}</b><div style="color:#9aa6c4;font-size:14px">${r.title || ""}</div>
      ${r.click ? `<button class="ck" data-u="${r.click}">Click orqali to'lash</button>` : ""}${r.payme ? `<button class="pm" data-u="${r.payme}">Payme orqali to'lash</button>` : ""}
      <button class="cl">Yopish</button></div></div>`);
    box.addEventListener("click", e => { const b = e.target.closest("button"); if (e.target === box || (b && b.classList.contains("cl"))) return box.remove(); if (b && b.dataset.u) { openUrl(b.dataset.u); box.remove(); } });
    document.body.appendChild(box);
    const un = F.onSnapshot(F.doc(fs, "payments/" + r.payId), s => { const d = s.data(); if (d && d.status === "paid") { un(); toast("✅ To'lov qabul qilindi"); } }, () => {});
    setTimeout(un, 30 * 60000);
  }

  /* ---------- Push token va rol ---------- */
  let pushTok = null;
  async function savePush(extra) {
    if (!me) return;
    const d = Object.assign({ updatedAt: Date.now() }, extra || {});
    if (pushTok) d.tokens = { [pushTok]: Date.now() };
    try { await F.setDoc(F.doc(fs, "pushtokens/" + me.uid), d, { merge: true }); } catch (e) { console.warn("push", e); }
  }

  window.ZovaServer = {
    has: k => !!FEAT[k],
    call, pay,
    role: () => savePush(),   // rol (role/ref) ni server o'zi belgilaydi — ilova faqat push tokenni yozadi
    refresh: async () => { try { await me.getIdToken(true); } catch (e) {} location.reload(); },
    signOut: async () => { try { if (NATIVE && NATIVE.logout) NATIVE.logout(); await auth.signOut(); } catch (e) {} location.reload(); },
  };
  /* Android "Orqaga" tugmasi uchun */
  window.ZovaBack = () => { try { if (typeof S === "undefined") return false; if (document.getElementById("zv-pay")) { document.getElementById("zv-pay").remove(); return true; } if (S.modal) { S.modal = null; render(); return true; } if (S.sheet) { S.sheet = null; render(); return true; } if (S.stack && S.stack.length > 1) { back(); return true; } } catch (e) {} return false; };

  /* ---------- Kirish: telefon raqam + SMS kod ---------- */
  function loginUI() {
    return new Promise(resolve => {
      const ov = el(`<div id="zv-ov"><div class="bx">
        <div style="font-size:54px">🛵</div><h1>Zova market</h1><div class="mu">Telefon raqamingiz bilan kiring — SMS orqali kod keladi</div>
        <input id="zv-ph" inputmode="tel" value="+998 " autocomplete="tel">
        <input id="zv-cd" inputmode="numeric" maxlength="6" placeholder="SMS kod" style="display:none" autocomplete="one-time-code">
        <div class="er" id="zv-er"></div>
        <button id="zv-go">Kod yuborish</button><div id="zv-rc"></div></div></div>`);
      document.body.appendChild(ov);
      const $ = id => ov.querySelector("#" + id), er = t => { $("zv-er").textContent = t || ""; };
      let conf = null, verifier = null;
      const ESKIZ = FEAT.smsLogin === "eskiz";   // kod Eskiz.uz orqali (server: otpSend/otpVerify)
      let sentPh = "";
      $("zv-go").onclick = async () => {
        er(""); const b = $("zv-go"); b.disabled = true;
        try {
          if (!conf) {
            const ph = $("zv-ph").value.replace(/[^\d+]/g, "");
            if (!/^\+998\d{9}$/.test(ph)) { er("Raqamni to'liq kiriting: +998 XX XXX XX XX"); b.disabled = false; return; }
            if (ESKIZ) { await call("otpSend", { phone: ph }); sentPh = ph; conf = { confirm: async c => { const r = await call("otpVerify", { phone: sentPh, code: c }); await A.signInWithCustomToken(auth, r.token); } }; }
            else {
              verifier = verifier || new A.RecaptchaVerifier(auth, "zv-rc", { size: "invisible" });
              conf = await A.signInWithPhoneNumber(auth, ph, verifier);
            }
            $("zv-ph").disabled = true; $("zv-cd").style.display = ""; $("zv-cd").focus(); b.textContent = "Kirish";
          } else {
            const c = $("zv-cd").value.replace(/\D/g, "");
            if (c.length !== 6) { er("SMS dagi 6 xonali kodni kiriting"); b.disabled = false; return; }
            await conf.confirm(c); ov.remove(); resolve();
          }
        } catch (e) {
          const c = (e && e.code) || "";
          if (ESKIZ) {   // server xabari o'zbekcha keladi
            er(e.message || "Xatolik");
            if (c === "invalid_argument" && conf && !/Avval|muddati|Juda/.test(e.message || "")) { b.disabled = false; return; }   // noto'g'ri kod — qayta kiritsin
            conf = null; $("zv-ph").disabled = false; $("zv-cd").style.display = "none"; $("zv-cd").value = ""; b.textContent = "Kod yuborish"; b.disabled = false; return;
          }
          er(c.includes("invalid-verification-code") ? "Kod noto'g'ri" : c.includes("too-many-requests") ? "Juda ko'p urinish. Birozdan keyin qayta urinib ko'ring" : c.includes("invalid-phone") ? "Telefon raqam noto'g'ri" : "Xatolik: " + (e.message || c));
          if (!c.includes("invalid-verification-code")) { try { verifier && verifier.clear(); } catch (x) {} verifier = null; $("zv-rc").innerHTML = ""; conf = null; $("zv-ph").disabled = false; $("zv-cd").style.display = "none"; b.textContent = "Kod yuborish"; }
        }
        b.disabled = false;
      };
    });
  }

  async function start() {
    if (!CONF) { console.error("ZOVA_FIREBASE_CONFIG topilmadi (firebase-config.js)"); readyRes({}); return; }
    const mods = await Promise.all([import(SDK + "firebase-app.js"), import(SDK + "firebase-auth.js"), import(SDK + "firebase-firestore.js"), import(SDK + "firebase-functions.js")]);
    A = mods[1]; F = mods[2]; Fn = mods[3];
    app = mods[0].initializeApp(CONF);
    auth = A.getAuth(app); auth.languageCode = "uz";
    try { fs = F.initializeFirestore(app, { ignoreUndefinedProperties: true, localCache: F.persistentLocalCache({ tabManager: F.persistentMultipleTabManager() }) }); }
    catch (e) { fs = F.getFirestore(app); }
    fns = Fn.getFunctions(app, REGION);

    me = await new Promise(r => { const u = A.onAuthStateChanged(auth, x => { u(); r(x); }); });
    /* Android: web sessiyasi telefondagi akkauntga tegishli bo'lmasa — chiqib, qaytadan kiramiz */
    if (me && NATIVE && NATIVE.uid) { let nu = ""; try { nu = NATIVE.uid(); } catch (e) {} if (nu && nu !== me.uid) { await auth.signOut(); me = null; } }
    if (!me && NATIVE) {   // Android: telefon raqam ilovaning o'zida tasdiqlangan — shu akkaunt bilan kiramiz
      const tok = await nativeCall("getAuthToken");
      if (tok) { try { me = (await A.signInWithCustomToken(auth, tok)).user; } catch (e) { console.warn(e); } }
    }
    if (!me) { await loginUI(); me = auth.currentUser; }

    /* Huquq darajasi (Ega / xodim / mijoz) faqat serverda belgilanadi */
    try { const r = await call("syncClaims", {}); if (r && r.changed) await me.getIdToken(true); } catch (e) { console.warn("claims", e); }
    lvl = ((await me.getIdTokenResult()).claims.lvl) || "";
    let first = true;
    F.onSnapshot(F.doc(fs, "claims/" + me.uid), s => { const d = s.data(); if (first) { first = false; return; } if (d && d.lvl !== lvl) ZovaServer.refresh(); }, () => {});

    if (NATIVE) { pushTok = await nativeCall("getPushToken"); savePush(); }
    readyRes({ db: dbApi, user: userApi, sample: FEAT.ai ? sample : null });
  }
  start().catch(e => { console.error(e); readyRes({}); });
})();
