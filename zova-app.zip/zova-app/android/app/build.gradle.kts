plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "uz.zova.market"
    compileSdk = 36

    defaultConfig {
        applicationId = "uz.zova.market"
        minSdk = 24
        targetSdk = 36
        versionCode = (project.findProperty("versionCode") as String?)?.toInt() ?: 1
        versionName = "1.0.${(project.findProperty("versionCode") as String?) ?: "0"}"
        buildConfigField("String", "ZOVA_URL", "\"${project.property("ZOVA_URL")}\"")
        buildConfigField("String", "ZOVA_REGION", "\"${project.property("ZOVA_REGION")}\"")
        buildConfigField("String", "ZOVA_SMS", "\"${project.findProperty("ZOVA_SMS") ?: "firebase"}\"")
    }

    // Imzo kaliti GitHub Actions secret'laridan keladi (bo'lmasa debug kaliti bilan imzolanadi)
    val ksPath = System.getenv("ZOVA_KEYSTORE")
    signingConfigs {
        if (ksPath != null && file(ksPath).exists()) {
            create("zova") {
                storeFile = file(ksPath)
                storePassword = System.getenv("ZOVA_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ZOVA_KEY_ALIAS")
                keyPassword = System.getenv("ZOVA_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.findByName("zova") ?: signingConfigs.getByName("debug")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.android.material:material:1.12.0")

    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-functions")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
