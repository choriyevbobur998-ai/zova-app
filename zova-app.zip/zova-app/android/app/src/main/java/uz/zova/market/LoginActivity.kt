package uz.zova.market

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import java.util.concurrent.TimeUnit

/** Telefon raqam + SMS kod orqali kirish. Kod Firebase Phone Auth yoki (ZOVA_SMS=eskiz) Eskiz.uz orqali keladi. */
class LoginActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance().apply { setLanguageCode("uz") } }
    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private val eskiz = BuildConfig.ZOVA_SMS == "eskiz"
    private val fns by lazy { FirebaseFunctions.getInstance(BuildConfig.ZOVA_REGION) }
    private var sentPhone: String? = null

    private lateinit var phone: EditText
    private lateinit var code: EditText
    private lateinit var go: Button
    private lateinit var resend: TextView
    private lateinit var err: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        phone = findViewById(R.id.phone); code = findViewById(R.id.code); go = findViewById(R.id.go)
        resend = findViewById(R.id.resend); err = findViewById(R.id.err); progress = findViewById(R.id.progress)
        go.setOnClickListener { if (verificationId == null) sendCode(false) else verify() }
        resend.setOnClickListener { sendCode(true) }
    }

    private fun normalized(): String? {
        val d = phone.text.toString().filter { it.isDigit() }
        val full = if (d.length == 9) "998$d" else d
        return if (full.length == 12 && full.startsWith("998")) "+$full" else null
    }

    private fun busy(b: Boolean) { progress.visibility = if (b) View.VISIBLE else View.GONE; go.isEnabled = !b }

    private fun sendCode(again: Boolean) {
        val number = normalized() ?: run { err.text = "Raqamni to'liq kiriting: +998 XX XXX XX XX"; return }
        err.text = ""; busy(true)
        if (eskiz) { eskizSend(number); return }
        val cb = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) = signIn(credential)   // SMS avtomatik o'qildi
            override fun onVerificationFailed(e: FirebaseException) {
                busy(false)
                err.text = when {
                    e is FirebaseAuthInvalidCredentialsException -> "Telefon raqam noto'g'ri"
                    (e.message ?: "").contains("too many", true) -> "Juda ko'p urinish. Birozdan keyin qayta urinib ko'ring"
                    else -> "SMS yuborilmadi: ${e.localizedMessage}"
                }
            }
            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                busy(false); verificationId = id; resendToken = token
                phone.isEnabled = false; code.visibility = View.VISIBLE; resend.visibility = View.VISIBLE
                go.text = "Kirish"; code.requestFocus()
            }
        }
        val opts = PhoneAuthOptions.newBuilder(auth).setPhoneNumber(number).setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this).setCallbacks(cb)
        if (again) resendToken?.let { opts.setForceResendingToken(it) }
        PhoneAuthProvider.verifyPhoneNumber(opts.build())
    }

    private fun verify() {
        val c = code.text.toString().filter { it.isDigit() }
        if (c.length != 6) { err.text = "SMS dagi 6 xonali kodni kiriting"; return }
        if (eskiz) eskizVerify(c) else signIn(PhoneAuthProvider.getCredential(verificationId!!, c))
    }

    private fun fnError(e: Exception?): String =
        (e as? FirebaseFunctionsException)?.message ?: "Internet aloqasini tekshiring"

    private fun eskizSend(number: String) {
        fns.getHttpsCallable("otpSend").call(mapOf("phone" to number)).addOnCompleteListener { t ->
            busy(false)
            if (t.isSuccessful) {
                sentPhone = number; verificationId = "eskiz"
                phone.isEnabled = false; code.visibility = View.VISIBLE; resend.visibility = View.VISIBLE
                go.text = "Kirish"; code.requestFocus()
            } else err.text = fnError(t.exception)
        }
    }

    private fun eskizVerify(c: String) {
        busy(true); err.text = ""
        fns.getHttpsCallable("otpVerify").call(mapOf("phone" to sentPhone, "code" to c)).addOnCompleteListener { t ->
            if (!t.isSuccessful) { busy(false); err.text = fnError(t.exception); return@addOnCompleteListener }
            val token = (t.result?.data as? Map<*, *>)?.get("token") as? String
            if (token == null) { busy(false); err.text = "Kirib bo'lmadi"; return@addOnCompleteListener }
            auth.signInWithCustomToken(token).addOnCompleteListener { r ->
                busy(false)
                if (r.isSuccessful) {
                    startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    finish()
                } else err.text = "Kirib bo'lmadi: ${r.exception?.localizedMessage}"
            }
        }
    }

    private fun signIn(credential: PhoneAuthCredential) {
        busy(true); err.text = ""
        auth.signInWithCredential(credential).addOnCompleteListener { t ->
            busy(false)
            if (t.isSuccessful) {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
            } else err.text = if (t.exception is FirebaseAuthInvalidCredentialsException) "Kod noto'g'ri" else "Kirib bo'lmadi: ${t.exception?.localizedMessage}"
        }
    }
}
