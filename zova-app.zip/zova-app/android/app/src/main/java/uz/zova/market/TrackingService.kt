package uz.zova.market

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import org.json.JSONArray

/**
 * Real-time kuryer kuzatuvi (Yandex Go kabi): faqat FAOL buyurtma davomida ishlaydi.
 * Joylashuv faqat shu buyurtma egasining hujjatiga yoziladi: orders/{mijoz}.orders.{id}.live
 * Buyurtma yetkazilgach/bekor qilingach servis o'zi to'xtaydi.
 */
class TrackingService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val targets = mutableListOf<Pair<String, String>>()   // (mijoz uid, buyurtma id)
    private val watchers = mutableMapOf<String, ListenerRegistration>()
    private var ref = ""
    private var last: Location? = null
    private var lastSent = 0L

    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.lastLocation?.let { onPos(it) } }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("track", MODE_PRIVATE)
        val json = intent?.getStringExtra(EXTRA_TARGETS) ?: prefs.getString(EXTRA_TARGETS, "[]")!!
        ref = intent?.getStringExtra(EXTRA_REF) ?: prefs.getString(EXTRA_REF, "")!!
        prefs.edit().putString(EXTRA_TARGETS, json).putString(EXTRA_REF, ref).apply()

        targets.clear()
        try { val a = JSONArray(json); for (i in 0 until a.length()) { val o = a.getJSONObject(i); targets += o.getString("uid") to o.getString("oid") } } catch (_: Exception) { }

        // startForegroundService dan keyin har doim avval startForeground chaqirilishi shart
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        try { ServiceCompat.startForeground(this, 77, notification(), type) } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        if (targets.isEmpty() || FirebaseAuth.getInstance().currentUser == null) { stopNow(); return START_NOT_STICKY }

        watchOrders()
        fused.removeLocationUpdates(cb)
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000L).setMinUpdateIntervalMillis(3000L).build()
        try { fused.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (_: SecurityException) { stopNow() }
        return START_STICKY
    }

    /** Buyurtma tugasa (yetkazildi / bekor) — kuzatuvdan chiqariladi */
    private fun watchOrders() {
        val uids = targets.map { it.first }.toSet()
        watchers.keys.filter { it !in uids }.forEach { watchers.remove(it)?.remove() }
        for (uid in uids) if (uid !in watchers) watchers[uid] = db.document("orders/$uid").addSnapshotListener { s, _ ->
            val orders = s?.get("orders") as? Map<*, *> ?: return@addSnapshotListener
            val done = targets.filter { it.first == uid && (orders[it.second] as? Map<*, *>)?.get("status").let { st -> st == "delivered" || st == "cancelled" } }
            if (done.isNotEmpty()) { targets.removeAll(done); if (targets.isEmpty()) stopNow() }
        }
    }

    private fun onPos(p: Location) {
        val now = System.currentTimeMillis()
        val moved = last?.distanceTo(p)?.let { it >= 12f } ?: true
        if (now - lastSent < 4000 || (!moved && now - lastSent < 20000)) return     // harakatda ~4 s, turganda ~20 s
        last = p; lastSent = now
        val live = hashMapOf<String, Any?>(
            "lat" to Math.round(p.latitude * 1e6) / 1e6, "lng" to Math.round(p.longitude * 1e6) / 1e6,
            "acc" to p.accuracy.toInt(), "heading" to if (p.hasBearing()) p.bearing.toInt() else null,
            "speed" to if (p.hasSpeed()) Math.round(p.speed * 10) / 10.0 else null, "at" to now, "src" to "android"
        )
        for ((uid, oid) in targets.toList())
            db.document("orders/$uid").update(FieldPath.of("orders", oid, "live"), live, "updatedAt", now)
        if (ref.isNotEmpty()) db.document("staffcodes/$ref").update("lat", live["lat"], "lng", live["lng"], "locAt", now)
    }

    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, ZovaApp.CH_TRACK)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Jonli kuzatuv yoqilgan")
            .setContentText("Mijoz sizni xaritada ko'rmoqda · ${targets.size} ta faol buyurtma")
            .setOngoing(true).setContentIntent(pi).build()
    }

    private fun stopNow() {
        getSharedPreferences("track", MODE_PRIVATE).edit().clear().apply()
        try { fused.removeLocationUpdates(cb) } catch (_: Exception) { }
        watchers.values.forEach { it.remove() }; watchers.clear()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { fused.removeLocationUpdates(cb) } catch (_: Exception) { }
        watchers.values.forEach { it.remove() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TARGETS = "targets"
        const val EXTRA_REF = "ref"
    }
}
