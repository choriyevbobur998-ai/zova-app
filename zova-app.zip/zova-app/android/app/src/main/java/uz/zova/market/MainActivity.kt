package uz.zova.market

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import com.google.firebase.auth.FirebaseAuth

/**
 * Asosiy oyna: ZOVA market web-ilovasi (Firebase Hosting) WebView ichida ochiladi.
 * Ilovaning barcha bo'limlari (mijoz, kuryer, do'kon, admin, Ega) bitta kod bazasida —
 * Android qismi esa telefon imkoniyatlarini beradi: SMS bilan kirish, GPS, push, to'lov ilovalari.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    val appHost: String? = Uri.parse(BuildConfig.ZOVA_URL).host
    private val authHost: String? = appHost?.replace(".web.app", ".firebaseapp.com")
    @Volatile var currentHost: String? = null
    private var pendingTrack: Pair<String, String>? = null

    private val locationPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r[Manifest.permission.ACCESS_FINE_LOCATION] == true || r[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        geoCallback?.invoke(geoOrigin, ok, false); geoCallback = null
        if (ok) pendingTrack?.let { (j, rf) -> pendingTrack = null; setTracking(j, rf) }
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val filePick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseAuth.getInstance().currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        web = WebView(this)
        setContentView(web)
        // Android 15: ilova butun ekranni egallaydi — status bar va klaviatura uchun joy qoldiramiz
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom); WindowInsetsCompat.CONSUMED
        }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = false          // reklama videolari ovozsiz avtomatik o'ynaydi
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "$userAgentString ZovaAndroid/${BuildConfig.VERSION_NAME}"
        }
        web.setBackgroundColor(Color.parseColor("#060A16"))
        web.addJavascriptInterface(ZovaBridge(this, web), "ZovaNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                if (!req.isForMainFrame) return false
                val u = req.url
                if (u.scheme == "https" && (u.host == appHost || u.host == authHost)) return false
                openExternal(u.toString()); return true                  // tel:, xarita, Click/Payme, Google rasm qidiruvi
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) { currentHost = url?.let { Uri.parse(it).host } }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { currentHost = url?.let { Uri.parse(it).host } }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (hasLocation()) callback.invoke(origin, true, false)
                else { geoOrigin = origin; geoCallback = callback; locationPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
            }
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = cb
                return try { filePick.launch(params.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
            }
            override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.ZovaBack && window.ZovaBack()) ? 'y' : 'n'") { r ->
                    if (r?.contains("y") == true) return@evaluateJavascript
                    if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) web.loadUrl(BuildConfig.ZOVA_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); if (::web.isInitialized) web.saveState(outState) }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Bildirishnoma bosilganda ilova shunchaki oldinga chiqadi; holat Firestore orqali darhol yangilanadi.
    }

    fun hasLocation() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Kuryer kuzatuvini yoqish/o'chirish (faqat ilova ekranda bo'lganda ishga tushiriladi) */
    fun setTracking(json: String, ref: String) {
        val n = try { org.json.JSONArray(json).length() } catch (_: Exception) { 0 }
        val i = Intent(this, TrackingService::class.java)
        if (n == 0) { stopService(i); pendingTrack = null; return }
        if (!hasLocation()) { pendingTrack = json to ref; locationPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)); return }
        if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) { pendingTrack = json to ref; return }
        i.putExtra(TrackingService.EXTRA_TARGETS, json).putExtra(TrackingService.EXTRA_REF, ref)
        try { ContextCompat.startForegroundService(this, i) } catch (_: Exception) { pendingTrack = json to ref }
    }

    override fun onResume() {
        super.onResume()
        if (hasLocation()) pendingTrack?.let { (j, r) -> pendingTrack = null; setTracking(j, r) }
    }

    fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    fun logout() {
        stopService(Intent(this, TrackingService::class.java))
        FirebaseAuth.getInstance().signOut()
        startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
