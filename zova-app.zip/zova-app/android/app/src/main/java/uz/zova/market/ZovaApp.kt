package uz.zova.market

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

class ZovaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
            nm.createNotificationChannel(NotificationChannel(CH_ORDERS, "Buyurtmalar", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Buyurtma holati, yangi buyurtmalar, to'lovlar"
                setSound(sound, attrs); enableVibration(true)
            })
            nm.createNotificationChannel(NotificationChannel(CH_NEWS, "Yangiliklar va aksiyalar", NotificationManager.IMPORTANCE_DEFAULT))
            nm.createNotificationChannel(NotificationChannel(CH_TRACK, "Jonli kuzatuv", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Kuryer faol buyurtmani yetkazayotganda ko'rinadi"
            })
        }
    }

    companion object {
        const val CH_ORDERS = "orders"
        const val CH_NEWS = "news"
        const val CH_TRACK = "tracking"
    }
}
