package uz.zova.market

import android.app.PendingIntent
import android.content.Intent
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.webkit.WebView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject

/**
 * Web-ilova ↔ Android ko'prigi. JavaScript'da `window.ZovaNative` nomi bilan ko'rinadi
 * (web/zova-server.js uni ishlatadi). Asinxron javoblar `window.__zovaCb(id, qiymat)` orqali qaytadi.
 */
class ZovaBridge(private val act: MainActivity, private val web: WebView) {

    /** Ko'prik faqat o'z ilovamiz sahifasida ishlaydi — begona sahifa token ololmaydi */
    private fun trusted(): Boolean = act.currentHost == act.appHost

    private fun reply(id: String, value: String?) {
        val js = "window.__zovaCb && window.__zovaCb(${JSONObject.quote(id)}, ${if (value == null) "null" else JSONObject.quote(value)})"
        web.post { web.evaluateJavascript(js, null) }
    }

    /** Telefon raqami Android'da tasdiqlangan akkaunt bilan web qismiga kirish uchun bir martalik token */
    @JavascriptInterface
    fun getAuthToken(id: String) {
        if (!trusted()) return reply(id, null)
        FirebaseFunctions.getInstance(BuildConfig.ZOVA_REGION).getHttpsCallable("webToken").call()
            .addOnSuccessListener { r -> reply(id, ((r.data as? Map<*, *>)?.get("token")) as? String) }
            .addOnFailureListener { reply(id, null) }
    }

    /** Push-bildirishnoma tokeni (FCM) */
    @JavascriptInterface
    fun getPushToken(id: String) {
        if (!trusted()) return reply(id, null)
        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { reply(id, it) }
            .addOnFailureListener { reply(id, null) }
    }

    /**
     * Kuryerning faol buyurtmalari: [{"uid":"…","oid":"…"}]. Bo'sh ro'yxat — kuzatuv to'xtaydi.
     * Ilova yopilsa ham TrackingService joylashuvni yuborib turadi.
     */
    @JavascriptInterface
    fun trackSet(json: String, courierRef: String) {
        if (!trusted()) return
        act.runOnUiThread { act.setTracking(json, courierRef) }
    }

    /** Joriy Android akkaunti (web sessiyasi bilan solishtirish uchun) */
    @JavascriptInterface
    fun uid(): String = if (trusted()) FirebaseAuth.getInstance().currentUser?.uid ?: "" else ""

    /** Click / Payme to'lov sahifasi yoki ilovasini ochish */
    @JavascriptInterface
    fun openUrl(url: String) {
        if (!trusted() || !(url.startsWith("https://") || url.startsWith("tel:"))) return
        act.runOnUiThread { act.openExternal(url) }
    }

    @JavascriptInterface
    fun logout() { if (trusted()) act.runOnUiThread { act.logout() } }

    /** Ilova ichidagi bildirishnomani telefon bildirishnomasi qilib ko'rsatish */
    @JavascriptInterface
    fun notify(title: String, body: String) {
        if (!trusted()) return
        val pi = PendingIntent.getActivity(act, 0, Intent(act, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(act, ZovaApp.CH_ORDERS).setSmallIcon(R.drawable.ic_notify).setColor(0xFF1F7BFF.toInt())
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build()
        try { NotificationManagerCompat.from(act).notify((System.currentTimeMillis() % 100000).toInt(), n) } catch (_: SecurityException) { }
    }

    @JavascriptInterface
    fun version(): String = BuildConfig.VERSION_NAME
}
