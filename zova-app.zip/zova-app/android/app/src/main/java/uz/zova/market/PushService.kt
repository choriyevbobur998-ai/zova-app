package uz.zova.market

import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Push-bildirishnomalar: ilova yopiq bo'lsa ham buyurtma holati, yangi buyurtma, jarima, yangiliklar keladi. */
class PushService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().document("pushtokens/$uid")
            .set(mapOf("tokens" to mapOf(token to System.currentTimeMillis()), "updatedAt" to System.currentTimeMillis()), SetOptions.merge())
    }

    override fun onMessageReceived(msg: RemoteMessage) {
        // Ilova ochiq bo'lganda tizim bildirishnomani o'zi ko'rsatmaydi — shu yerda ko'rsatamiz
        val title = msg.notification?.title ?: msg.data["title"] ?: return
        val body = msg.notification?.body ?: msg.data["body"] ?: ""
        val channel = msg.notification?.channelId ?: ZovaApp.CH_ORDERS
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, channel)
            .setSmallIcon(R.drawable.ic_notify)
            .setColor(0xFF1F7BFF.toInt())
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).setContentIntent(pi).build()
        try { NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % 100000).toInt(), n) } catch (_: SecurityException) { }
    }
}
