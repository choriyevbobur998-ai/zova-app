# WebView JS ko'prigi nomlari saqlanadi
-keepclassmembers class uz.zova.market.ZovaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
