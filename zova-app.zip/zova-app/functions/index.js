/* =====================================================================
   ZOVA market — server (Firebase Cloud Functions, Node 20)
   ---------------------------------------------------------------------
   • syncClaims / webToken      — rollar (Ega / xodim / mijoz) va Android→web kirish
   • hireVerify                 — kuryerni ishga qabul kodi serverda tekshiriladi
   • createPayment              — onlayn to'lov (buyurtma, kuryer hisobi, jarima)
   • clickPrepare/clickComplete — Click SHOP-API
   • payme                      — Payme Merchant API (JSON-RPC)
   • ai                         — ZOVA AI (Gemini)
   • imgSearch / imgProxy       — mahsulotning haqiqiy rasmini topish (Brave Search)
   • push*                      — telefon yopiq bo'lsa ham bildirishnoma (FCM)
   ===================================================================== */
const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentWritten, onDocumentCreated } = require("firebase-functions/v2/firestore");
const { setGlobalOptions, logger } = require("firebase-functions/v2");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { defineString, defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();
const FieldPath = admin.firestore.FieldPath;
const REGION = "europe-central2";
setGlobalOptions({ region: REGION, maxInstances: 10 });

/* ---------- Sozlamalar (.env yoki `firebase functions:secrets:set`) ---------- */
const OWNER_PHONES = defineString("OWNER_PHONES", { default: "" });          // "+998901234567,+998..."
const APP_URL = defineString("APP_URL", { default: "" });                    // https://PROJECT.web.app
const CLICK_SERVICE_ID = defineString("CLICK_SERVICE_ID", { default: "" });
const CLICK_MERCHANT_ID = defineString("CLICK_MERCHANT_ID", { default: "" });
const CLICK_SECRET = defineSecret("CLICK_SECRET_KEY");
const PAYME_MERCHANT_ID = defineString("PAYME_MERCHANT_ID", { default: "" });
const PAYME_KEY = defineSecret("PAYME_KEY");
const PAYME_TEST = defineString("PAYME_TEST", { default: "false" });
const GEMINI_KEY = defineSecret("GEMINI_API_KEY");
const GEMINI_MODEL = defineString("GEMINI_MODEL", { default: "gemini-2.5-flash" });
const BRAVE_KEY = defineSecret("BRAVE_SEARCH_KEY");
const SMS_ON = defineString("SMS_ON", { default: "false" });                  // true — Eskiz.uz orqali SMS yuboriladi
const SMS_FROM = defineString("SMS_FROM", { default: "4546" });               // Eskiz'dagi jo'natuvchi nomi
const SMS_DAILY_MAX = defineString("SMS_DAILY_MAX", { default: "1000" });     // kunlik SMS chegarasi (pul isrof bo'lmasin)
const ESKIZ_EMAIL = defineSecret("ESKIZ_EMAIL");
const ESKIZ_PASSWORD = defineSecret("ESKIZ_PASSWORD");

const now = () => Date.now();
const need = (c, msg) => { if (!c) throw new HttpsError("failed-precondition", msg); };
const authed = req => { if (!req.auth) throw new HttpsError("unauthenticated", "Kirish talab qilinadi"); return req.auth.uid; };
const isStaffReq = req => !!(req.auth && ["owner", "admin", "store"].includes(req.auth.token.lvl));

/* =====================================================================
   ROLLAR
   lvl = "owner"   — OWNER_PHONES ro'yxatidagi telefon raqam (Ega)
   lvl = "admin"   — Ega tasdiqlagan admin (security/main.admins)
   lvl = "courier" — ishga qabul qilingan kuryer · lvl = "store" — Ega tasdiqlagan do'kon
   bo'sh           — oddiy mijoz.  ref — kuryer/do'kon ID si (firestore.rules shuni tekshiradi)
   ===================================================================== */
async function computeClaims(uid) {
  let user; try { user = await admin.auth().getUser(uid); } catch { return { lvl: "", changed: false }; }
  const owners = OWNER_PHONES.value().split(",").map(s => s.replace(/[^\d+]/g, "")).filter(Boolean);
  let lvl = "", ref = "";
  if (user.phoneNumber && owners.includes(user.phoneNumber)) lvl = "owner";
  else {
    const sec = await db.doc("security/main").get();
    if (sec.exists && (sec.data().admins || []).includes(uid)) { lvl = "admin"; ref = "a_" + uid; }
    else {
      const q = await db.collection("staffcodes").where("uid", "==", uid).get();
      const ok = q.docs.find(d => { const x = d.data(); return (x.type === "courier" || x.type === "store") && x.active === true && !x.dismissed && !x.pending; });
      if (ok) { const x = ok.data(); lvl = x.type; ref = x.type === "store" ? (x.refId || "") : ok.id; }
    }
  }
  const cc = user.customClaims || {};
  await db.doc("pushtokens/" + uid).set({ role: lvl || "customer", ref }, { merge: true });
  if ((cc.lvl || "") !== lvl || (cc.ref || "") !== ref) {
    await admin.auth().setCustomUserClaims(uid, Object.assign({}, cc, { lvl, ref }));
    await db.doc("claims/" + uid).set({ lvl, ref, v: now() });
    logger.info("claims", uid, cc.lvl || "-", "→", lvl || "-");
    return { lvl, changed: true };
  }
  return { lvl, changed: false };
}
exports.syncClaims = onCall(async req => computeClaims(authed(req)));
/* Android ilova telefon raqamni o'zi tasdiqlaydi; shu akkaunt bilan web qismiga kirish uchun token */
exports.webToken = onCall(async req => ({ token: await admin.auth().createCustomToken(authed(req)) }));

exports.claimsOnStaff = onDocumentWritten({ document: "staffcodes/{id}", secrets: [ESKIZ_EMAIL, ESKIZ_PASSWORD] }, async ev => {
  const b = ev.data.before.exists ? ev.data.before.data() : {}, a = ev.data.after.exists ? ev.data.after.data() : {};
  const uids = new Set([b.uid, a.uid].filter(Boolean));
  for (const u of uids) await computeClaims(u);
  if (!a.uid) return;
  const hired = a.active === true && !a.dismissed && !(b.active === true && !b.dismissed) && (a.type === "courier" || a.type === "store");
  if (!hired && a.phoneOk && a.phone === b.phone) return;   // GPS kabi oddiy yangilanishlarda ortiqcha so'rov yo'q
  // Arizadagi telefon — SMS kod bilan tasdiqlangan raqam bo'lsin (boshqa raqam yozib bo'lmaydi)
  let ph = ""; try { ph = (await admin.auth().getUser(a.uid)).phoneNumber || ""; } catch (e) {}
  if (ph && a.phone !== ph) await ev.data.after.ref.update({ phone: ph, phoneOk: true }).catch(() => {});
  // Ishga qabul qilinganda SMS
  if (hired)
    await smsOnce(`hired_${ev.params.id}_${a.hiredAt || a.approvedAt || ""}`, ph,
      `Zova market: tabriklaymiz, siz ${a.type === "courier" ? "kuryer" : "do'kon"} sifatida tasdiqlandingiz. Ilovaga kiring.`);
});
exports.claimsOnSecurity = onDocumentWritten("security/main", async ev => {
  const b = (ev.data.before.exists && ev.data.before.data().admins) || [], a = (ev.data.after.exists && ev.data.after.data().admins) || [];
  const diff = [...b.filter(x => !a.includes(x)), ...a.filter(x => !b.includes(x))];
  for (const u of diff) await computeClaims(u);
});

/* ---------- Kuryerni ishga qabul qilish kodi (admin beradi) ---------- */
const HIRE_MAX = 10;   // bitta kod uchun 10 ta xato — kod bekor bo'ladi va admin qurilmasi avtomatik yangisini yaratadi
exports.hireVerify = onCall(async req => {
  const uid = authed(req), code = String((req.data || {}).code || "").replace(/\D/g, "");
  const id = "k_" + uid, ref = db.doc("staffcodes/" + id), tryRef = db.doc("hiretry/" + uid), hRef = db.doc("hirecodes/" + id);
  const res = await db.runTransaction(async tx => {
    const [s, h, t] = await Promise.all([tx.get(ref), tx.get(hRef), tx.get(tryRef)]);
    if (!s.exists || !s.data().pending) return { ok: false, err: "Ariza topilmadi. Orqaga qaytib qayta kiring." };
    if (!h.exists) return { ok: false, err: "Qabul kodi hali tayyor emas — admin ilovani ochishi bilan yaratiladi. Admin bilan bog'laning." };
    const want = String(h.data().code || ""), tr = t.exists ? t.data() : {};
    const n = tr.code === want ? (tr.n || 0) : 0;
    if (tr.last && now() - tr.last < 2000) return { ok: false, err: "Biroz kuting va qayta urinib ko'ring" };
    const ok = want.length === 6 && code.length === 6 && crypto.timingSafeEqual(Buffer.from(want), Buffer.from(code));
    if (!ok) {
      if (n + 1 >= HIRE_MAX) { tx.delete(hRef); tx.update(ref, { hireHash: "", updatedAt: now() }); tx.set(tryRef, { n: 0, code: "", last: now() }); return { ok: false, err: "Juda ko'p noto'g'ri urinish — kod bekor qilindi. Admindan yangi kodni so'rang." }; }
      tx.set(tryRef, { n: n + 1, code: want, last: now() });
      return { ok: false, err: "Kod noto'g'ri. Admin bergan kodni tekshiring." };
    }
    tx.update(ref, { active: true, pending: false, hireHash: "", hiredAt: now(), updatedAt: now() });
    tx.delete(hRef); tx.delete(tryRef);
    return { ok: true, name: s.data().name || "" };
  });
  if (res.ok) {
    await db.collection("audit").add({ action: "admin", detail: "Kuryer ishga qabul qilindi: " + res.name, at: now(), by: uid, server: true });
    await computeClaims(uid);
  }
  return res;
});

/* =====================================================================
   ONLAYN TO'LOV
   payments/{payId}: { type: order|topup|fine, uid, amount, status: new|paid|cancelled, ... }
   Summa HAR DOIM serverda bazadan olinadi — telefon ilovasi summani o'zgartira olmaydi.
   ===================================================================== */
async function cfg() { const s = await db.doc("config/app").get(); return s.exists ? s.data() : {}; }
const payTitle = p => p.type === "order" ? `Buyurtma № ${String(p.oid).slice(-6).toUpperCase()}` : p.type === "topup" ? "Kuryer hisobini to'ldirish" : "Jarima to'lovi";

exports.createPayment = onCall(async req => {
  const uid = authed(req), a = req.data || {};
  let p;
  if (a.type === "order") {
    const s = await db.doc("orders/" + uid).get(), o = s.exists && (s.data().orders || {})[a.oid];
    need(o, "Buyurtma topilmadi"); need(o.pay === "online", "Bu buyurtma onlayn to'lov uchun emas");
    need(!o.paid, "Buyurtma allaqachon to'langan"); need(o.status !== "cancelled", "Buyurtma bekor qilingan");
    const pc = await db.doc(`pricecheck/${uid}_${a.oid}`).get();
    need(!pc.exists || pc.data().ok, "Buyurtma narxi katalog bilan mos kelmadi — buyurtmani qaytadan bering");
    p = { type: "order", uid, oid: a.oid, amount: Math.round(+o.total || 0) };
  } else if (a.type === "topup") {
    const c = await db.doc("staffcodes/" + a.cid).get();
    need(c.exists && c.data().uid === uid && c.data().type === "courier", "Faqat o'z hisobingizni to'ldira olasiz");
    const w = (await cfg()).wallet || {}, min = Math.max(1000, +w.topMin || 100000), amt = Math.round(+a.amount || 0);
    need(amt >= min, `Eng kam to'ldirish — ${min} so'm`); need(amt <= 5000000, "Summa juda katta");
    p = { type: "topup", uid, cid: a.cid, name: c.data().name || "", amount: amt };
  } else if (a.type === "fine") {
    const f = await db.doc("fines/" + a.fineId).get(); need(f.exists, "Jarima topilmadi");
    const x = f.data(); need(x.status === "unpaid", "Bu jarima to'lanadigan holatda emas");
    let mine = x.role === "customer" && x.tid === uid;
    if (!mine && x.role === "courier") { const c = await db.doc("staffcodes/" + x.tid).get(); mine = c.exists && c.data().uid === uid; }
    if (!mine && x.role === "store") { const q = await db.collection("staffcodes").where("uid", "==", uid).where("refId", "==", x.tid).get(); mine = !q.empty; }
    if (!mine && x.role === "admin") { const c = await db.doc("staffcodes/" + x.tid).get(); mine = c.exists && c.data().uid === uid; }
    need(mine, "Bu jarima sizga tegishli emas");
    p = { type: "fine", uid, fineId: a.fineId, amount: Math.round(+x.amount || 0) };
  } else throw new HttpsError("invalid-argument", "Noma'lum to'lov turi");
  need(p.amount >= 1000, "Summa juda kichik");
  // Shu buyurtma/jarima uchun ochiq to'lov bo'lsa — o'shani qaytaramiz (ikki marta to'lanmasin)
  let payId = "";
  if (p.type !== "topup") {
    const key = p.type === "order" ? "oid" : "fineId";
    const ex = await db.collection("payments").where("uid", "==", uid).where(key, "==", p[key]).where("status", "==", "new").get();
    const same = ex.docs.find(d => d.data().amount === p.amount);
    if (same) payId = same.id;
    for (const d of ex.docs) if (d.id !== payId && !(d.data().payme && d.data().payme.state === 1) && !d.data().click) await d.ref.update({ status: "cancelled", cancelledAt: now() });
  }
  if (!payId) { payId = String(now()) + String(crypto.randomInt(100, 999)); await db.doc("payments/" + payId).set(Object.assign(p, { status: "new", createdAt: now() })); }
  const ret = APP_URL.value() || "";
  const click = CLICK_SERVICE_ID.value() ? `https://my.click.uz/services/pay?service_id=${CLICK_SERVICE_ID.value()}&merchant_id=${CLICK_MERCHANT_ID.value()}&amount=${p.amount}&transaction_param=${payId}${ret ? "&return_url=" + encodeURIComponent(ret) : ""}` : "";
  const payme = PAYME_MERCHANT_ID.value() ? `${PAYME_TEST.value() === "true" ? "https://test.paycom.uz" : "https://checkout.paycom.uz"}/${Buffer.from(`m=${PAYME_MERCHANT_ID.value()};ac.pay_id=${payId};a=${p.amount * 100};l=uz${ret ? ";c=" + ret : ""}`).toString("base64")}` : "";
  return { payId, amount: p.amount, title: payTitle(p), click, payme };
});

/* To'lov o'tdi — natijani bazaga yozish (bir marta) */
async function applyPaid(payId, via, extId) {
  const ref = db.doc("payments/" + payId);
  const p = await db.runTransaction(async tx => {
    const s = await tx.get(ref); if (!s.exists) return null;
    const d = s.data(); if (d.status === "paid") return null;
    tx.update(ref, { status: "paid", paidAt: now(), via, extId: String(extId || "") });
    return d;
  });
  if (!p) return;
  if (p.type === "order") {
    await db.doc("orders/" + p.uid).update(new FieldPath("orders", p.oid, "paid"), true, new FieldPath("orders", p.oid, "paidVia"), via, new FieldPath("orders", p.oid, "paidAt"), now(), "updatedAt", now());
    await push({ uid: p.uid }, "✅ To'lov qabul qilindi", `${payTitle(p)} · ${p.amount} so'm`);
  } else if (p.type === "topup") {
    await db.doc("kwal/pay_" + payId).set({ cid: p.cid, name: p.name || "", amount: p.amount, note: "Onlayn to'lov (" + via + ")", by: "server", byName: via, at: now() });
    await push({ role: "courier", ref: p.cid }, "💳 Hisobingiz to'ldirildi", `+${p.amount} so'm (${via})`);
  } else if (p.type === "fine") {
    await db.doc("fines/" + p.fineId).update({ status: "paid", paidVia: via, paidAt: now(), hist: admin.firestore.FieldValue.arrayUnion({ at: now(), txt: "Onlayn to'landi (" + via + ")" }) });
  }
}
async function cancelPay(payId) { await db.doc("payments/" + payId).update({ status: "cancelled", cancelledAt: now() }).catch(() => {}); }

/* ---------- Click SHOP-API (prepare / complete) ---------- */
const md5 = s => crypto.createHash("md5").update(s).digest("hex");
function clickCheck(b, prepareId) {
  const s = `${b.click_trans_id}${b.service_id}${CLICK_SECRET.value()}${b.merchant_trans_id}${prepareId !== undefined ? prepareId : ""}${b.amount}${b.action}${b.sign_time}`;
  return md5(s) === String(b.sign_string || "");
}
exports.clickPrepare = onRequest({ secrets: [CLICK_SECRET] }, async (req, res) => {
  const b = req.body || {}, base = { click_trans_id: b.click_trans_id, merchant_trans_id: b.merchant_trans_id };
  if (!clickCheck(b)) return res.json({ ...base, error: -1, error_note: "SIGN CHECK FAILED" });
  if (String(b.action) !== "0") return res.json({ ...base, error: -3, error_note: "Action not found" });
  const s = await db.doc("payments/" + b.merchant_trans_id).get();
  if (!s.exists) return res.json({ ...base, error: -5, error_note: "Order not found" });
  const p = s.data();
  if (p.status === "paid") return res.json({ ...base, error: -4, error_note: "Already paid" });
  if (p.status === "cancelled") return res.json({ ...base, error: -9, error_note: "Transaction cancelled" });
  if (p.payme && p.payme.state === 1) return res.json({ ...base, error: -9, error_note: "Payment in progress via Payme" });
  if (Math.abs(+b.amount - p.amount) > 0.01) return res.json({ ...base, error: -2, error_note: "Incorrect parameter amount" });
  const prepId = Number(String(now()).slice(-9));
  await s.ref.update({ click: { trans: String(b.click_trans_id), prepareId: prepId, at: now() } });
  res.json({ ...base, merchant_prepare_id: prepId, error: 0, error_note: "Success" });
});
exports.clickComplete = onRequest({ secrets: [CLICK_SECRET] }, async (req, res) => {
  const b = req.body || {}, base = { click_trans_id: b.click_trans_id, merchant_trans_id: b.merchant_trans_id };
  if (!clickCheck(b, b.merchant_prepare_id)) return res.json({ ...base, error: -1, error_note: "SIGN CHECK FAILED" });
  if (String(b.action) !== "1") return res.json({ ...base, error: -3, error_note: "Action not found" });
  const s = await db.doc("payments/" + b.merchant_trans_id).get();
  if (!s.exists) return res.json({ ...base, error: -5, error_note: "Order not found" });
  const p = s.data();
  if (!p.click || String(p.click.prepareId) !== String(b.merchant_prepare_id)) return res.json({ ...base, error: -6, error_note: "Transaction does not exist" });
  if (p.status === "paid") return res.json({ ...base, merchant_confirm_id: p.click.prepareId, error: -4, error_note: "Already paid" });
  if (p.status === "cancelled") return res.json({ ...base, error: -9, error_note: "Transaction cancelled" });
  if (Math.abs(+b.amount - p.amount) > 0.01) return res.json({ ...base, error: -2, error_note: "Incorrect parameter amount" });
  if (+b.error < 0) { await cancelPay(b.merchant_trans_id); return res.json({ ...base, error: -9, error_note: "Transaction cancelled" }); }
  await applyPaid(b.merchant_trans_id, "Click", b.click_trans_id);
  res.json({ ...base, merchant_confirm_id: p.click.prepareId, error: 0, error_note: "Success" });
});

/* ---------- Payme Merchant API ---------- */
const PM_TIMEOUT = 12 * 3600 * 1000;
exports.payme = onRequest({ secrets: [PAYME_KEY] }, async (req, res) => {
  const { id, method, params = {} } = req.body || {};
  const ok = result => res.json({ jsonrpc: "2.0", id, result });
  const fail = (code, msg, data) => res.json({ jsonrpc: "2.0", id, error: { code, message: { uz: msg, ru: msg, en: msg }, data } });
  const got = Buffer.from(String(req.headers.authorization || ""));
  const want = Buffer.from("Basic " + Buffer.from("Paycom:" + PAYME_KEY.value()).toString("base64"));
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return fail(-32504, "Ruxsat yo'q");
  const byAccount = async () => { const pid = String((params.account || {}).pay_id || ""); const s = pid && await db.doc("payments/" + pid).get(); return s && s.exists ? s : null; };
  const byTrans = async () => { const q = await db.collection("payments").where("payme.id", "==", String(params.id)).limit(1).get(); return q.empty ? null : q.docs[0]; };
  const view = pm => ({ create_time: pm.create_time || 0, perform_time: pm.perform_time || 0, cancel_time: pm.cancel_time || 0, transaction: pm.tid, state: pm.state, reason: pm.reason === undefined ? null : pm.reason });
  try {
    switch (method) {
      case "CheckPerformTransaction": {
        const s = await byAccount(); if (!s) return fail(-31050, "To'lov topilmadi", "pay_id");
        const p = s.data(); if (p.status !== "new") return fail(-31051, "To'lov allaqachon bajarilgan yoki bekor qilingan", "pay_id");
        if (+params.amount !== p.amount * 100) return fail(-31001, "Summa noto'g'ri");
        return ok({ allow: true });
      }
      case "CreateTransaction": {
        const s = await byAccount(); if (!s) return fail(-31050, "To'lov topilmadi", "pay_id");
        const p = s.data();
        if (p.payme && p.payme.id) {
          if (p.payme.id !== String(params.id)) return fail(-31051, "Bu to'lov boshqa tranzaksiya bilan band", "pay_id");
          if (p.payme.state !== 1) return fail(-31008, "Tranzaksiyani bajarib bo'lmaydi");
          if (now() - p.payme.create_time > PM_TIMEOUT) { await s.ref.update({ "payme.state": -1, "payme.reason": 4, "payme.cancel_time": now(), status: "cancelled" }); return fail(-31008, "Muddati o'tgan"); }
          return ok({ create_time: p.payme.create_time, transaction: p.payme.tid, state: 1 });
        }
        if (p.status !== "new") return fail(-31051, "To'lov allaqachon bajarilgan yoki bekor qilingan", "pay_id");
        if (p.click) return fail(-31051, "Bu to'lov Click orqali amalga oshirilmoqda", "pay_id");
        if (+params.amount !== p.amount * 100) return fail(-31001, "Summa noto'g'ri");
        const pm = { id: String(params.id), time: +params.time, create_time: now(), state: 1, tid: s.id };
        await s.ref.update({ payme: pm });
        return ok({ create_time: pm.create_time, transaction: pm.tid, state: 1 });
      }
      case "PerformTransaction": {
        const s = await byTrans(); if (!s) return fail(-31003, "Tranzaksiya topilmadi");
        const pm = s.data().payme;
        if (pm.state === 2) return ok({ transaction: pm.tid, perform_time: pm.perform_time, state: 2 });
        if (pm.state !== 1 || s.data().status !== "new") return fail(-31008, "Tranzaksiyani bajarib bo'lmaydi");
        if (now() - pm.create_time > PM_TIMEOUT) { await s.ref.update({ "payme.state": -1, "payme.reason": 4, "payme.cancel_time": now(), status: "cancelled" }); return fail(-31008, "Muddati o'tgan"); }
        const t = now(); await s.ref.update({ "payme.state": 2, "payme.perform_time": t });
        await applyPaid(s.id, "Payme", pm.id);
        return ok({ transaction: pm.tid, perform_time: t, state: 2 });
      }
      case "CancelTransaction": {
        const s = await byTrans(); if (!s) return fail(-31003, "Tranzaksiya topilmadi");
        const pm = s.data().payme;
        if (pm.state < 0) return ok({ transaction: pm.tid, cancel_time: pm.cancel_time, state: pm.state });
        if (pm.state === 2) return fail(-31007, "Bajarilgan to'lovni bekor qilib bo'lmaydi — qaytarish Ega orqali");
        const t = now(); await s.ref.update({ "payme.state": -1, "payme.reason": +params.reason || 0, "payme.cancel_time": t, status: "cancelled" });
        return ok({ transaction: pm.tid, cancel_time: t, state: -1 });
      }
      case "CheckTransaction": {
        const s = await byTrans(); if (!s) return fail(-31003, "Tranzaksiya topilmadi");
        return ok(view(s.data().payme));
      }
      case "GetStatement": {
        const q = await db.collection("payments").where("payme.time", ">=", +params.from).where("payme.time", "<=", +params.to).get();
        return ok({ transactions: q.docs.map(d => { const p = d.data(); return { id: p.payme.id, time: p.payme.time, amount: p.amount * 100, account: { pay_id: d.id }, ...view(p.payme) }; }) });
      }
      case "ChangePassword": return fail(-32400, "Kalitni Firebase'da yangilang: firebase functions:secrets:set PAYME_KEY");
      default: return fail(-32601, "Metod topilmadi");
    }
  } catch (e) { logger.error("payme", e); return fail(-32400, "Ichki xatolik"); }
});

/* =====================================================================
   ZOVA AI — Gemini (faqat ilova haqida javob beradi: buni ilova so'rovi belgilaydi)
   ===================================================================== */
exports.ai = onCall({ secrets: [GEMINI_KEY], timeoutSeconds: 60 }, async req => {
  const uid = authed(req), a = req.data || {};
  const lim = db.doc("ailimit/" + uid), minute = Math.floor(now() / 60000);
  const n = await db.runTransaction(async tx => { const s = await tx.get(lim), d = s.exists ? s.data() : {}; const c = d.m === minute ? (d.c || 0) + 1 : 1; tx.set(lim, { m: minute, c }); return c; });
  if (n > 15) throw new HttpsError("resource-exhausted", "Biroz kuting");
  const prompt = String(a.prompt || "").slice(0, 30000);
  const body = { contents: [{ role: "user", parts: [{ text: prompt }] }], generationConfig: Object.assign({ temperature: 0.4, maxOutputTokens: 2048 }, a.json ? { responseMimeType: "application/json" } : {}) };
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL.value()}:generateContent`, { method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": GEMINI_KEY.value() }, body: JSON.stringify(body) });
  if (r.status === 429) throw new HttpsError("resource-exhausted", "Biroz kuting");
  if (!r.ok) { logger.error("gemini", r.status, await r.text()); throw new HttpsError("unavailable", "AI javob bermadi"); }
  const j = await r.json();
  const text = ((((j.candidates || [])[0] || {}).content || {}).parts || []).map(p => p.text || "").join("").trim();
  if (!a.json) return { text };
  try { return { data: JSON.parse(text.replace(/^```(json)?|```$/g, "").trim()) }; } catch { throw new HttpsError("unavailable", "AI javobi noto'g'ri"); }
});

/* =====================================================================
   Mahsulotning haqiqiy rasmi — Brave Search Image API
   ===================================================================== */
exports.imgSearch = onCall({ secrets: [BRAVE_KEY] }, async req => {
  if (!isStaffReq(req)) throw new HttpsError("permission-denied", "Faqat xodimlar");
  const q = String((req.data || {}).q || "").trim().slice(0, 120); if (q.length < 2) return { items: [] };
  const r = await fetch(`https://api.search.brave.com/res/v1/images/search?q=${encodeURIComponent(q)}&count=10&safesearch=strict&country=ALL`, { headers: { accept: "application/json", "X-Subscription-Token": BRAVE_KEY.value() } });
  if (!r.ok) { logger.error("brave", r.status, await r.text()); throw new HttpsError("unavailable", "Rasm qidiruvi ishlamadi"); }
  const j = await r.json();
  return { items: (j.results || []).map(x => ({ link: (x.properties || {}).url, thumb: (x.thumbnail || {}).src, title: x.title || "" })).filter(x => x.link && x.thumb).slice(0, 8) };
});
const privateHost = h => /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|0\.|\[?::1|metadata)/i.test(h);
exports.imgProxy = onCall(async req => {
  if (!isStaffReq(req)) throw new HttpsError("permission-denied", "Faqat xodimlar");
  let u; try { u = new URL(String((req.data || {}).url || "")); } catch { throw new HttpsError("invalid-argument", "Havola noto'g'ri"); }
  if (!/^https?:$/.test(u.protocol) || privateHost(u.hostname)) throw new HttpsError("invalid-argument", "Havola noto'g'ri");
  const r = await fetch(u, { redirect: "follow", headers: { "user-agent": "Mozilla/5.0 ZovaMarket" }, signal: AbortSignal.timeout(12000) });
  const type = (r.headers.get("content-type") || "").split(";")[0];
  if (!r.ok || !/^image\/(jpeg|png|webp|gif|avif)$/.test(type)) throw new HttpsError("unavailable", "Rasm yuklanmadi");
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length > 4 * 1024 * 1024) throw new HttpsError("unavailable", "Rasm juda katta");
  return { dataUrl: `data:${type};base64,${buf.toString("base64")}` };
});

/* =====================================================================
   PUSH-BILDIRISHNOMALAR (ilova yopiq bo'lsa ham keladi)
   pushtokens/{uid}: { tokens: {token: ts}, role, ref }
   ===================================================================== */
async function tokensFor(t) {
  let docs = [];
  if (t.uid) { const s = await db.doc("pushtokens/" + t.uid).get(); if (s.exists) docs = [s]; }
  else if (t.role) {
    let q = db.collection("pushtokens").where("role", "in", Array.isArray(t.role) ? t.role : [t.role]);
    if (t.ref) q = q.where("ref", "==", t.ref);
    docs = (await q.get()).docs;
  }
  const out = [];
  for (const d of docs) for (const tok of Object.keys(d.data().tokens || {})) out.push({ tok, ref: d.ref });
  return out;
}
async function push(target, title, body, data) {
  const list = await tokensFor(target); if (!list.length) return;
  const r = await admin.messaging().sendEachForMulticast({
    tokens: list.map(x => x.tok),
    notification: { title, body },
    data: Object.fromEntries(Object.entries(Object.assign({ title, body }, data || {})).map(([k, v]) => [k, String(v == null ? "" : v)])),
    android: { priority: "high", notification: { channelId: "orders", sound: "default" } },
  });
  r.responses.forEach((x, i) => {
    const c = x.error && x.error.code;
    if (c === "messaging/registration-token-not-registered" || c === "messaging/invalid-registration-token")
      list[i].ref.update(new FieldPath("tokens", list[i].tok), admin.firestore.FieldValue.delete()).catch(() => {});
  });
}
const STATUS = { new: "Yangi", accepted: "Qabul qilindi", preparing: "Tayyorlanmoqda", delivering: "Yo'lda", delivered: "Yetkazildi", cancelled: "Bekor qilindi" };
const shortId = id => String(id || "").slice(-6).toUpperCase();

exports.pushOnOrder = onDocumentWritten({ document: "orders/{uid}", secrets: [ESKIZ_EMAIL, ESKIZ_PASSWORD] }, async ev => {
  const uid = ev.params.uid;
  const b = (ev.data.before.exists && ev.data.before.data().orders) || {}, a = (ev.data.after.exists && ev.data.after.data().orders) || {};
  const jobs = [];
  const PF = ["items", "subtotal", "total", "fee", "service", "discount", "bonus"];
  for (const [oid, o] of Object.entries(a)) {
    const p = b[oid];
    if (o.kind !== "parcel" && (!p || PF.some(k => JSON.stringify(p[k]) !== JSON.stringify(o[k])))) jobs.push(priceCheck(uid, oid, o));
    const kind = o.kind === "parcel" ? "📦 Kuryer chaqiruvi" : "🧾 Buyurtma";
    if (!p) {   // yangi buyurtma
      if (o.storeId && o.storeId !== "main" && o.storeId !== "parcel") jobs.push(push({ role: "store", ref: o.storeId }, "🛎️ Yangi buyurtma", `№ ${shortId(oid)} · ${o.total || 0} so'm`, { oid }));
      jobs.push(push({ role: ["admin", "owner"] }, o.kind === "parcel" ? "📦 Yangi kuryer chaqiruvi" : "🛎️ Yangi buyurtma", `№ ${shortId(oid)} · ${o.name || ""} · ${o.total || 0} so'm`, { oid }));
      continue;
    }
    if (p.status !== o.status) jobs.push(push({ uid }, `${kind} № ${shortId(oid)}`, STATUS[o.status] || String(o.status || ""), { oid }));
    if (o.status === "delivered" && p.status !== "delivered") jobs.push(smsDelivered(uid, oid, o));
    const cNew = o.courierId || o.assignedCourierId, cOld = p.courierId || p.assignedCourierId;
    if (cNew && cNew !== cOld && o.status !== "delivered" && o.status !== "cancelled") jobs.push(push({ role: "courier", ref: cNew }, "🛵 Sizga yangi buyurtma", `№ ${shortId(oid)} · ${o.address || o.area || ""}`, { oid }));
    if (o.status === "cancelled" && p.status !== "cancelled" && cOld) jobs.push(push({ role: "courier", ref: cOld }, "❌ Buyurtma bekor qilindi", `№ ${shortId(oid)}`, { oid }));
  }
  await Promise.all(jobs);
});
/* Buyurtma narxini katalog bilan solishtirish (mijoz narxni o'zgartirib yubora olmasin).
   Natija pricecheck/{uid}_{oid} ga yoziladi — uni faqat server yozadi, xodimlar ko'radi. */
async function priceCheck(uid, oid, o) {
  const why = [];
  const items = Array.isArray(o.items) ? o.items : [];
  const snaps = items.length ? await db.getAll(...items.map(it => db.doc("products/" + String(it.id || "x")))) : [];
  let sub = 0;
  items.forEach((it, i) => {
    const s = snaps[i], qty = +it.qty || 0;
    if (!s || !s.exists) { why.push(`"${it.name}" katalogda yo'q`); return; }
    const price = +s.data().price || 0;
    if (Math.abs(price - (+it.price || 0)) > 0.5) why.push(`"${it.name}": narx ${it.price}, katalogda ${price}`);
    if (qty <= 0 || qty > 999) why.push(`"${it.name}": miqdor noto'g'ri`);
    sub += price * qty;
  });
  if (Math.abs(sub - (+o.subtotal || 0)) > 1) why.push(`Mahsulotlar summasi ${o.subtotal}, hisob bo'yicha ${Math.round(sub)}`);
  const exp = (+o.subtotal || 0) + (+o.fee || 0) + (+o.service || 0) - (+o.discount || 0) - (+o.bonus || 0);
  if (Math.abs(exp - (+o.total || 0)) > 1) why.push(`Jami ${o.total}, hisob bo'yicha ${Math.round(exp)}`);
  if ((+o.fee || 0) < 0 || (+o.discount || 0) < 0 || (+o.bonus || 0) < 0 || (+o.discount || 0) > (+o.subtotal || 0)) why.push("Chegirma yoki yetkazish narxi noto'g'ri");
  if ((+o.discount || 0) > 0 && !o.promoId) why.push("Chegirma promo kodsiz");
  if ((+o.bonus || 0) > 0) { const bs = await db.doc("bonus/" + uid).get(); if (!bs.exists || (+bs.data().balance || 0) + 1 < +o.bonus) why.push("Bonus balansdan ko'p"); }
  const ok = !why.length;
  await db.doc(`pricecheck/${uid}_${oid}`).set({ uid, oid, ok, why, total: +o.total || 0, at: now() });
  if (!ok) await push({ role: ["admin", "owner"] }, "⚠️ Buyurtma narxi mos emas", `№ ${shortId(oid)}: ${why[0]}`, { oid });
}

exports.pushOnFine = onDocumentCreated("fines/{id}", async ev => {
  const f = ev.data.data(), t = f.role === "customer" ? { uid: f.tid } : { role: f.role === "admin" ? "admin" : f.role, ref: f.tid };
  await push(t, "⚖️ Sizga jarima yozildi", `${f.reason || ""} · ${f.amount || 0} so'm${f.status === "review" ? " (ko'rib chiqilmoqda)" : ""}`);
});
exports.pushOnNews = onDocumentWritten("news/{id}", async ev => {
  const b = ev.data.before.exists ? ev.data.before.data() : null, a = ev.data.after.exists ? ev.data.after.data() : null;
  if (!a || !a.published || (b && b.published)) return;
  await admin.messaging().send({ topic: "news", notification: { title: "📰 " + (a.title || "Yangilik"), body: String(a.body || "").slice(0, 140) }, android: { notification: { channelId: "news" } } });
});
/* Ega e'loni — hammaga yoki tanlangan guruhga push */
exports.pushOnNotice = onDocumentCreated("notices/{id}", async ev => {
  const n = ev.data.data(), to = n.to || ["all"], title = "📢 " + (n.title || "E'lon"), body = String(n.body || "").slice(0, 200);
  if (to.includes("all")) { await admin.messaging().send({ topic: "news", notification: { title, body }, android: { priority: "high", notification: { channelId: "orders" } } }); return; }
  const roles = to.map(r => r === "admin" ? ["admin", "owner"] : [r]).flat();
  await push({ role: [...new Set(roles)].slice(0, 10) }, title, body);
});
exports.pushOnComplaint = onDocumentWritten("complaints/{uid}", async ev => {
  const b = (ev.data.before.exists && ev.data.before.data().items) || {}, a = (ev.data.after.exists && ev.data.after.data().items) || {};
  for (const [id, it] of Object.entries(a)) if (it.reply && (!b[id] || b[id].reply !== it.reply)) await push({ uid: ev.params.uid }, "📣 Murojaatingizga javob keldi", String(it.reply).slice(0, 140));
});
exports.pushTopics = onDocumentWritten("pushtokens/{uid}", async ev => {
  const b = Object.keys((ev.data.before.exists && ev.data.before.data().tokens) || {}), a = Object.keys((ev.data.after.exists && ev.data.after.data().tokens) || {});
  const add = a.filter(t => !b.includes(t));
  if (add.length) await admin.messaging().subscribeToTopic(add, "news").catch(e => logger.warn("topic", e));
});

/* Xavfsizlik jurnali har hafta yangilanadi: 7 kundan eski yozuvlar o'chiriladi (har kuni 03:00) */
exports.auditClean = onSchedule({ schedule: "0 3 * * *", timeZone: "Asia/Tashkent" }, async () => {
  const q = await db.collection("audit").where("at", "<", now() - 7 * 864e5).limit(450).get();
  const b = db.batch(); q.docs.forEach(d => b.delete(d.ref)); if (!q.empty) await b.commit();
  logger.info("audit cleaned", q.size);
});


/* =====================================================================
   SMS (Eskiz.uz) — yetkazildi xabari, ishga qabul, kirish kodi
   Kalitlar: firebase functions:secrets:set ESKIZ_EMAIL / ESKIZ_PASSWORD, .env da SMS_ON=true
   Eslatma: Eskiz har bir SMS matnini oldindan tasdiqlaydi (kabinet → "Shablonlar").
   Pastdagi matnlarni o'sha yerga yuborib, tasdiqlatib oling.
   ===================================================================== */
const SMS_TXT = {
  code: c => `Zova market: kirish kodingiz ${c}. Kodni hech kimga bermang.`,
  delivered: id => `Zova market: ${id} raqamli buyurtmangiz yetkazildi. Xaridingiz uchun rahmat!`,
};
let eskizTok = null;
async function eskizToken(force) {
  if (!force && eskizTok && now() - eskizTok.at < 20 * 864e5) return eskizTok.t;
  const s = !force && await db.doc("server/eskiz").get();
  if (s && s.exists && now() - s.data().at < 20 * 864e5) { eskizTok = s.data(); return eskizTok.t; }
  const fd = new FormData(); fd.append("email", ESKIZ_EMAIL.value()); fd.append("password", ESKIZ_PASSWORD.value());
  const r = await fetch("https://notify.eskiz.uz/api/auth/login", { method: "POST", body: fd });
  const j = await r.json().catch(() => ({}));
  const t = j && j.data && j.data.token; if (!t) throw new Error("Eskiz login: " + r.status + " " + JSON.stringify(j).slice(0, 200));
  eskizTok = { t, at: now() }; await db.doc("server/eskiz").set(eskizTok);
  return t;
}
async function sendSms(phone, text) {
  const num = String(phone || "").replace(/\D/g, "");
  if (SMS_ON.value() !== "true" || !/^998\d{9}$/.test(num)) return false;
  const day = new Date(now() + 5 * 36e5).toISOString().slice(0, 10);   // Toshkent kuni
  const cnt = db.doc("server/sms_" + day);
  const n = await db.runTransaction(async tx => { const x = await tx.get(cnt); const v = (x.exists ? x.data().n : 0) + 1; tx.set(cnt, { n: v, at: now() }); return v; });
  if (n > (+SMS_DAILY_MAX.value() || 1000)) { logger.error("SMS kunlik chegara oshdi", n); return false; }
  for (let i = 0; i < 2; i++) {
    const fd = new FormData(); fd.append("mobile_phone", num); fd.append("message", text); fd.append("from", SMS_FROM.value());
    const r = await fetch("https://notify.eskiz.uz/api/message/sms/send", { method: "POST", body: fd, headers: { Authorization: "Bearer " + await eskizToken(i > 0) } });
    if (r.status === 401) continue;   // token eskirgan — yangisini olib qayta
    if (r.ok) return true;
    logger.error("eskiz send", r.status, (await r.text()).slice(0, 300)); return false;
  }
  return false;
}
/* Bir xil SMS ikki marta ketmasin */
async function smsOnce(key, phone, text) {
  if (SMS_ON.value() !== "true" || !phone) return;
  try { await db.doc("smslog/" + key).create({ phone, at: now() }); } catch (e) { return; }
  try { const ok = await sendSms(phone, text); await db.doc("smslog/" + key).update({ ok }); } catch (e) { logger.error("sms", key, e); }
}
async function smsDelivered(uid, oid, o) {
  let ph = ""; try { ph = (await admin.auth().getUser(uid)).phoneNumber || ""; } catch (e) {}
  if (!ph) ph = o.phone || "";
  await smsOnce(`dlv_${uid}_${oid}`, ph, SMS_TXT.delivered(shortId(oid)));
}

/* ---------- Kirish kodi Eskiz orqali (Firebase SMS o'rniga, ixtiyoriy) ----------
   Ilova: web/firebase-config.js → ZOVA_FEATURES.smsLogin = "eskiz", Android: gradle.properties → ZOVA_SMS=eskiz */
const OTP_TTL = 5 * 60e3, OTP_GAP = 60e3, OTP_DAY = 5, OTP_TRIES = 5;
const otpHash = (ph, c) => crypto.createHash("sha256").update("zova-otp:" + ph + ":" + c).digest("hex");
const normPhone = p => { const d = String(p || "").replace(/\D/g, ""); const f = d.length === 9 ? "998" + d : d; return /^998\d{9}$/.test(f) ? "+" + f : ""; };
exports.otpSend = onCall({ secrets: [ESKIZ_EMAIL, ESKIZ_PASSWORD] }, async req => {
  const ph = normPhone(req.data && req.data.phone); need(ph, "Telefon raqam noto'g'ri");
  need(SMS_ON.value() === "true", "SMS xizmati yoqilmagan");
  const ref = db.doc("otp/" + ph.slice(1)), t = now(), day = new Date(t + 5 * 36e5).toISOString().slice(0, 10);
  const code = String(crypto.randomInt(100000, 1000000));
  await db.runTransaction(async tx => {
    const s = await tx.get(ref), x = s.exists ? s.data() : {};
    if (x.sentAt && t - x.sentAt < OTP_GAP) throw new HttpsError("resource-exhausted", "Kodni qayta so'rash uchun 1 daqiqa kuting");
    const cnt = x.day === day ? (x.cnt || 0) : 0;
    if (cnt >= OTP_DAY) throw new HttpsError("resource-exhausted", "Bugun juda ko'p kod so'raldi. Ertaga urinib ko'ring");
    tx.set(ref, { hash: otpHash(ph, code), exp: t + OTP_TTL, tries: 0, sentAt: t, day, cnt: cnt + 1 });
  });
  const ok = await sendSms(ph, SMS_TXT.code(code));
  if (!ok) { await ref.update({ sentAt: 0 }); throw new HttpsError("unavailable", "SMS yuborilmadi. Birozdan keyin urinib ko'ring"); }
  return { ok: true, ttl: OTP_TTL / 1000 };
});
exports.otpVerify = onCall(async req => {
  const ph = normPhone(req.data && req.data.phone), c = String((req.data && req.data.code) || "").replace(/\D/g, "");
  need(ph && c.length === 6, "Kod noto'g'ri");
  const ref = db.doc("otp/" + ph.slice(1));
  const res = await db.runTransaction(async tx => {
    const s = await tx.get(ref); if (!s.exists || !s.data().hash) return "none";
    const x = s.data();
    if (now() > x.exp) { tx.update(ref, { hash: "" }); return "exp"; }
    if (x.tries >= OTP_TRIES) { tx.update(ref, { hash: "" }); return "many"; }
    if (x.hash !== otpHash(ph, c)) { tx.update(ref, { tries: x.tries + 1 }); return "bad"; }
    tx.update(ref, { hash: "" }); return "ok";
  });
  if (res !== "ok") throw new HttpsError("invalid-argument", { bad: "Kod noto'g'ri", exp: "Kod muddati o'tdi. Yangisini so'rang", many: "Juda ko'p xato. Yangi kod so'rang", none: "Avval kod so'rang" }[res]);
  let u; try { u = await admin.auth().getUserByPhoneNumber(ph); } catch (e) { u = await admin.auth().createUser({ phoneNumber: ph }); }
  return { token: await admin.auth().createCustomToken(u.uid) };
});

/* =====================================================================
   AKKAUNTNI O'CHIRISH (Google Play va App Store talabi)
   Shaxsiy ma'lumotlar butunlay o'chiriladi. Buyurtma va pul yozuvlari hisob uchun
   ism-raqamsiz qoladi. Ega akkauntini bu yo'l bilan o'chirib bo'lmaydi.
   ===================================================================== */
exports.deleteAccount = onCall(async req => {
  const uid = authed(req);
  if (req.auth.token.lvl === "owner") throw new HttpsError("failed-precondition", "Ega akkauntini ilovadan o'chirib bo'lmaydi");
  const GONE = "O'chirilgan foydalanuvchi";
  // 1) Buyurtmalar: profil o'chadi, buyurtmalardagi ism, telefon, manzil va izohlar yashiriladi
  const oref = db.doc("orders/" + uid), os = await oref.get();
  if (os.exists) {
    const orders = os.data().orders || {}, clean = {};
    for (const [id, o] of Object.entries(orders)) {
      const active = o.status && !["delivered", "cancelled"].includes(o.status);
      clean[id] = Object.assign({}, o, { name: GONE, phone: "", address: active ? o.address || "" : "", note: "", comment: "", lat: active ? (o.lat ?? null) : null, lng: active ? (o.lng ?? null) : null, deletedUser: true });
    }
    await oref.set({ profile: { name: GONE, deleted: true, deletedAt: now() }, orders: clean });
  }
  // 2) Shaxsiy hujjatlar
  await Promise.all(["bonus", "complaints", "pushtokens", "claims", "ufines", "ailimit"].map(c => db.doc(`${c}/${uid}`).delete().catch(() => {})));
  const bl = db.doc("blacklist/" + uid), bs = await bl.get();
  if (bs.exists) await bl.update({ name: GONE, phone: "", deletedUser: true });   // qora ro'yxat belgisi qoladi (suiiste'mol bo'lmasin)
  // 3) Xodim bo'lsa: ishdan bo'shatiladi, ism-raqam va hujjatlar o'chadi (jarima va hisob yozuvlari qoladi)
  const sc = await db.collection("staffcodes").where("uid", "==", uid).get();
  for (const d of sc.docs) {
    const x = d.data();
    await d.ref.update({ name: GONE, first: "", last: "", phone: "", lat: admin.firestore.FieldValue.delete(), lng: admin.firestore.FieldValue.delete(), online: false, active: false, dismissed: true, deletedUser: true, updatedAt: now() });
    if (x.appId) for (const c of ["staffdocs", "staffimg"]) {
      const q = await db.collection(c).where("appId", "==", x.appId).get();
      await Promise.all(q.docs.map(z => z.ref.delete()));
    }
  }
  const sec = await db.doc("security/main").get();
  if (sec.exists && (sec.data().admins || []).includes(uid)) await sec.ref.update({ admins: admin.firestore.FieldValue.arrayRemove(uid) });
  // 4) Kirish akkaunti (telefon raqam) o'chiriladi
  await admin.auth().deleteUser(uid);
  logger.info("account deleted", uid);
  return { ok: true };
});

/* =====================================================================
   XARITA API: manzil qidirish (geocoding)
   • YANDEX_GEOCODER_KEY (.env) berilsa — Yandex Geocoder (O'zbekiston ko'chalari eng to'liq)
   • bo'lmasa — OpenStreetMap Nominatim (bepul, sekundiga 1 so'rov)
   {lat,lng} → { street, full }  ·  {q} → { items: [{title, sub, lat, lng}] }
   ===================================================================== */
const YANDEX_GEOCODER_KEY = defineString("YANDEX_GEOCODER_KEY", { default: "" });
const GEO_BOX = { w: 65.6, s: 38.3, e: 67.4, n: 39.4 };   // Qashqadaryo atrofi
const geoCache = new Map(), geoHits = new Map();
function geoLimit(uid) {
  const m = Math.floor(now() / 60000), k = uid + ":" + m, n = (geoHits.get(k) || 0) + 1;
  geoHits.set(k, n); if (geoHits.size > 5000) geoHits.clear();
  if (n > 40) throw new HttpsError("resource-exhausted", "Juda ko'p so'rov — biroz kuting");
}
async function geoFetch(url, headers) {
  const r = await fetch(url, { headers: Object.assign({ "User-Agent": "ZovaMarket/1.0 (" + (APP_URL.value() || "zova") + ")" }, headers || {}), signal: AbortSignal.timeout(6000) });
  if (!r.ok) throw new Error("geo " + r.status);
  return r.json();
}
exports.geocode = onCall({ maxInstances: 3 }, async req => {
  const uid = authed(req); geoLimit(uid);
  const d = req.data || {}, ykey = YANDEX_GEOCODER_KEY.value();
  if (typeof d.lat === "number" && typeof d.lng === "number") {
    need(d.lat > GEO_BOX.s - 1 && d.lat < GEO_BOX.n + 1 && d.lng > GEO_BOX.w - 1 && d.lng < GEO_BOX.e + 1, "Hududdan tashqarida");
    const key = "r:" + d.lat.toFixed(4) + "," + d.lng.toFixed(4);
    if (geoCache.has(key)) return geoCache.get(key);
    let out = { street: "", full: "" };
    try {
      if (ykey) {
        const j = await geoFetch(`https://geocode-maps.yandex.ru/1.x/?apikey=${encodeURIComponent(ykey)}&geocode=${d.lng},${d.lat}&format=json&lang=uz_UZ&results=1&kind=house`);
        const g = (((j.response || {}).GeoObjectCollection || {}).featureMember || [])[0];
        if (g) out = { street: g.GeoObject.name || "", full: [g.GeoObject.name, g.GeoObject.description].filter(Boolean).join(", ") };
      } else {
        const j = await geoFetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${d.lat}&lon=${d.lng}&zoom=18&addressdetails=1&accept-language=uz,ru`);
        const a = j.address || {}, road = a.road || a.pedestrian || a.residential || a.neighbourhood || a.suburb || a.village || a.hamlet || "";
        out = { street: [road, a.house_number].filter(Boolean).join(", "), full: j.display_name || "" };
      }
    } catch (e) { logger.warn("geocode reverse", e.message); }
    geoCache.set(key, out); if (geoCache.size > 3000) geoCache.clear();
    return out;
  }
  const q = String(d.q || "").trim().slice(0, 80);
  need(q.length >= 2, "Qidiruv so'zi qisqa");
  const key = "q:" + q.toLowerCase();
  if (geoCache.has(key)) return geoCache.get(key);
  let items = [];
  try {
    if (ykey) {
      const j = await geoFetch(`https://geocode-maps.yandex.ru/1.x/?apikey=${encodeURIComponent(ykey)}&geocode=${encodeURIComponent(q)}&format=json&lang=uz_UZ&results=6&bbox=${GEO_BOX.w},${GEO_BOX.s}~${GEO_BOX.e},${GEO_BOX.n}&rspn=1`);
      items = ((((j.response || {}).GeoObjectCollection || {}).featureMember) || []).map(f => { const [lng, lat] = f.GeoObject.Point.pos.split(" ").map(Number); return { title: f.GeoObject.name, sub: f.GeoObject.description || "", lat, lng }; });
    } else {
      const j = await geoFetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q)}&limit=6&countrycodes=uz&viewbox=${GEO_BOX.w},${GEO_BOX.n},${GEO_BOX.e},${GEO_BOX.s}&bounded=1&accept-language=uz,ru`);
      items = (j || []).map(x => ({ title: (x.name || x.display_name || "").split(",")[0], sub: (x.display_name || "").split(",").slice(1, 3).join(",").trim(), lat: +x.lat, lng: +x.lon }));
    }
  } catch (e) { logger.warn("geocode search", e.message); }
  const out = { items: items.filter(x => isFinite(x.lat) && isFinite(x.lng)).slice(0, 6) };
  geoCache.set(key, out);
  return out;
});
