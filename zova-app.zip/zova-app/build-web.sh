#!/bin/sh
# Claude ilovasidagi eng yangi tezkor.html ni web/index.html ga aylantiradi.
# Ishlatish: ./build-web.sh path/to/tezkor.html
set -e
SRC="${1:-tezkor.html}"
python3 - "$SRC" web/index.html <<'PY'
import sys
s = open(sys.argv[1], encoding="utf-8").read()
inj = '<script src="firebase-config.js"></script>\n<script src="zova-server.js"></script>\n'
i = s.index("<script")
s = s[:i] + inj + s[i:]
s = s.replace("OFFSITE_CHECK = true", "OFFSITE_CHECK = false")
if "<!doctype" not in s[:200].lower():
    s = ('<!doctype html>\n<html lang="uz">\n<head>\n<meta charset="utf-8">\n'
         '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
         '<meta name="theme-color" content="#060A16">\n<link rel="manifest" href="manifest.json">\n</head>\n<body>\n' + s + '\n</body>\n</html>\n')
open(sys.argv[2], "w", encoding="utf-8").write(s)
print("web/index.html tayyor:", len(s) // 1024, "KB")
PY
